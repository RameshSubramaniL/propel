<?php
include 'db_connect.php';
if(isset($_GET['id'])){
	//echo "SELECT * FROM category_list where id={$_GET['id']}";
	$qry = $conn1->query("SELECT * FROM tickets where id={$_GET['id']}")->fetch_array();
	foreach($qry as $k => $v){
		$$k = $v;
	}
}
?>
<div class="container-fluid">
	<form action="" id="manage-status">
		<input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
		<div id="msg" class="form-group"></div>
		<div class="form-group">
			<label for="department" class="control-label">Attend Date</label>
			<input type="date" class="form-control form-control-sm" name="attend_date" id="attend_date" required="required" value="<?php echo isset($attend_date) ? $attend_date : '' ?>">
		</div>	
        <div class="form-group">
			<label for="department" class="control-label">Reached Time</label>
			<input type="time" class="form-control form-control-sm" name="reached_time" id="reached_time" required="required" value="<?php echo isset($reached_time) ? $reached_time : '' ?>">
		</div>	
        <div class="form-group">
			<label for="department" class="control-label">Resolved Date</label>
			<input type="date" class="form-control form-control-sm" name="resolve_date" id="resolve_date" required="required" value="<?php echo isset($resolve_date) ? $resolve_date : '' ?>">
		</div>	
        <div class="form-group">
			<label for="department" class="control-label">Resolved Time</label>
			<input type="time" class="form-control form-control-sm" name="resolve_time" id="resolve_time" required="required" value="<?php echo isset($resolve_time) ? $resolve_time : '' ?>">
		</div>	
		<div class="form-group">
			<label for="department" class="control-label">Status</label>
			<select class="form-control" name="status">
				<option value="2">Resolved</option>
			</select>
		</div>	
	</form>
</div>
<script>
	$(document).ready(function(){
		
		$('#manage-status').submit(function(e){
			
			$("input").prop('required',true);
			e.preventDefault();
			start_load()
			$('#msg').html('')
			$.ajax({
				url:'ajax.php?action=update_status',
				method:'POST',
				data:$(this).serialize(),
				success:function(resp){
					//alert(resp);
					if(resp == 1){
						alert_toast("Ticket Status Updated Successfully.","success");
						setTimeout(function(){
							location.reload()	
						},1750)
					}else if(resp == 2){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Category already exist.</div>')
						end_load()
					}
					else if(resp == 3){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Please Fill Field.</div>')
						end_load()
					}
				}
			})
		})
	})

</script>