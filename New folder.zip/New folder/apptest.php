<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="bootstrap.min.css">
  <script src="jquery.min.js"></script>
  <script src="bootstrap.min.js"></script>
</head>
<style>
table, th, td {
 border: 1px solid black; 
 border-collapse: collapse;
}
</style>
<body>

<div class="container">
  <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#home">Home</a></li>
    <li><a data-toggle="tab" href="#page2">Page 2</a></li>
    <li><a data-toggle="tab" href="#page3">Page 3</a></li>
    <li><a data-toggle="tab" href="#page4">Page 4</a></li>
  </ul>

  <div class="tab-content">
    <div id="home" class="tab-pane fade in active">
	<div class="form-group">
	<label for="">1. MOP TARGET VS ACHIEVED </label>
		<br>

<table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="871" style="margin-left: 0.1pt;">
 <tbody><tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:31.4pt">
  <td width="57" rowspan="3" style="width:34.05pt;border:solid windowtext 1.0pt;
  border-left:double windowtext 2.25pt;background:lime;padding:0cm 5.4pt 0cm 5.4pt;
  height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">KPI
  / MOP No.<o:p></o:p></span></b></p>
  </td>
  <td width="227" rowspan="3" style="width:136.25pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">Major
  Activities<o:p></o:p></span></b></p>
  </td>
  <td width="213" rowspan="3" style="width:127.5pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">KPI
  / MOP<o:p></o:p></span></b></p>
  </td>
  <td width="53" rowspan="3" style="width:31.5pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">UOM
  <o:p></o:p></span></b></p>
  </td>
  <td width="60" rowspan="3" style="width:36.0pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;Last
  Year Actual <o:p></o:p></span></b></p>
  </td>
  <td width="60" rowspan="3" style="width:36.0pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;YTD
  Target <o:p></o:p></span></b></p>
  </td>
  <td width="60" rowspan="3" style="width:36.0pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;YTD
  Actual <o:p></o:p></span></b></p>
  </td>
  <td width="68" rowspan="3" style="width:40.5pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;Growth
  on Last Year <o:p></o:p></span></b></p>
  </td>
  <td width="75" rowspan="3" style="width:45.05pt;border:solid windowtext 1.0pt;
  border-left:none;background:lime;padding:0cm 5.4pt 0cm 5.4pt;height:31.4pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:9.0pt;mso-bidi-font-size:10.0pt;line-height:115%;
  font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;Variance<br>
  (YTDT - YTDA) <o:p></o:p></span></b></p>
  </td>

<!--[if !supportMisalignedRows]-->
  <td style="height:31.4pt;border:none" width="0" height="52"></td>
  <!--[endif]-->
 </tr>
 <tr style="mso-yfti-irow:1;height:31.4pt">
  <!--[if !supportMisalignedRows]-->
  <td style="height:31.4pt;border:none" width="0" height="52"></td>
  <!--[endif]-->
 </tr>
 <tr style="mso-yfti-irow:2;height:31.4pt">
  <!--[if !supportMisalignedRows]-->
  <td style="height:31.4pt;border:none" width="0" height="52"></td>
  <!--[endif]-->
 </tr>
 <tr style="mso-yfti-irow:3;height:78.55pt">
  <td width="57" style="width:34.05pt;border-top:none;border-left:double windowtext 2.25pt;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">1<o:p></o:p></span></b></p>
  </td>
  <td width="227" style="width:136.25pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="213" nowrap="" style="width:127.5pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal"><span lang="EN-US" style="color:black">&nbsp;</span></p>
  </td>
  <td width="53" style="width:31.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="68" style="width:40.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="75" style="width:45.05pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <!--[if !supportMisalignedRows]-->
  <td style="height:78.55pt;border:none" width="0" height="131"></td>
  <!--[endif]-->
 </tr>
 <tr style="mso-yfti-irow:4;height:71.75pt">
  <td width="57" style="width:34.05pt;border-top:none;border-left:double windowtext 2.25pt;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">2<o:p></o:p></span></b></p>
  </td>
  <td width="227" style="width:136.25pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;<o:p></o:p></span></b></p>
  </td>
  <td width="213" nowrap="" style="width:127.5pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:71.75pt">
  <p class="MsoNormal"><span lang="EN-US" style="color:black">&nbsp;</span></p>
  </td>
  <td width="53" style="width:31.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="68" style="width:40.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="75" style="width:45.05pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:71.75pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;<o:p></o:p></span></b></p>
  </td>
  <!--[if !supportMisalignedRows]-->
  <td style="height:71.75pt;border:none" width="0" height="120"></td>
  <!--[endif]-->
 </tr>
 <tr style="mso-yfti-irow:5;height:78.55pt">
  <td width="57" style="width:34.05pt;border-top:none;border-left:double windowtext 2.25pt;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">3<o:p></o:p></span></b></p>
  </td>
  <td width="227" style="width:136.25pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;<o:p></o:p></span></b></p>
  </td>
  <td width="213" nowrap="" style="width:127.5pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal"><span lang="EN-US" style="color:black">&nbsp;</span></p>
  </td>
  <td width="53" style="width:31.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="68" style="width:40.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="75" style="width:45.05pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:78.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;<o:p></o:p></span></b></p>
  </td>
  <!--[if !supportMisalignedRows]-->
  <td style="height:78.55pt;border:none" width="0" height="131"></td>
  <!--[endif]-->
 </tr>

<tr style="mso-yfti-irow:6;mso-yfti-lastrow:yes;height:95.55pt">
  <td width="57" style="width:34.05pt;border-top:none;border-left:double windowtext 2.25pt;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">4<o:p></o:p></span></b></p>
  </td>
  <td width="227" style="width:136.25pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;<o:p></o:p></span></b></p>
  </td>
  <td width="213" style="width:127.5pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:95.55pt">
  <p class="MsoNormal"><span lang="EN-US" style="font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;;color:blue">&nbsp;<o:p></o:p></span></p>
  </td>
  <td width="53" style="width:31.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;<o:p></o:p></span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:12.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="60" style="width:36.0pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="68" style="width:40.5pt;border-top:none;border-left:none;border-bottom:
  solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;</span></b></p>
  </td>
  <td width="75" style="width:45.05pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid windowtext 1.0pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:95.55pt">
  <p class="MsoNormal" align="center" style="text-align:center"><b><span lang="EN-US" style="font-size:10.0pt;line-height:115%;font-family:&quot;Arial Narrow&quot;,&quot;sans-serif&quot;;
  mso-bidi-font-family:&quot;Arial Narrow&quot;">&nbsp;<o:p></o:p></span></b></p>
  </td>
  <!--[if !supportMisalignedRows]-->
  <td style="height:95.55pt;border:none" width="0" height="159"></td>
  <!--[endif]-->
 </tr>
</tbody></table>

	</div>

</div>

    <div id="page2" class="tab-pane fade">
      <div class="form-group">

<p class="MsoNormal" style="text-align:justify"><span lang="EN-US">2. WHAT DO YOU CONSIDER
TO BE YOUR MOST IMPORTANT ACHIEVEMENTS AND CONTRIBUTIONS OF THE THIRD QUARTER OCT 2021 TO DEC 2021?<o:p></o:p></span></p><table class="MsoTableGrid" border="1" cellspacing="0" cellpadding="0" style="border: none;">
 <tbody><tr>
  <td width="798" valign="top" style="width:478.8pt;border:solid windowtext 1.0pt;
  mso-border-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt">
  <p class="MsoNormal" style="text-align:justify"><b><span lang="EN-US">&nbsp;</span></b></p>
  <p class="MsoNormal" style="text-align:justify"><b><span lang="EN-US">&nbsp;</span></b></p>
  <p class="MsoNormal" style="text-align:justify"><b><span lang="EN-US">&nbsp;</span></b></p>
  <p class="MsoNormal" style="text-align:justify"><b><span lang="EN-US">&nbsp;</span></b></p>
  <p class="MsoNormal" style="text-align:justify"><b><span lang="EN-US">&nbsp;</span></b></p>
  </td>
 </tr>
</tbody></table><p class="MsoNormal" style="text-align:justify"><b><span lang="EN-US">&nbsp;</span></b></p><p class="MsoNormal" style="text-align:justify"><b><span lang="EN-US">&nbsp;3. RATE THE BELOW:<o:p></o:p></span></b></p><p>


</p><table class="MsoNormalTable" border="0" cellspacing="0" cellpadding="0" width="104" style="margin-left: -5.3pt;">
 <tbody><tr style="mso-yfti-irow:0;mso-yfti-firstrow:yes;height:25.4pt">
  <td width="29" nowrap="" style="width:23.25pt;border:solid windowtext 1.0pt;
  border-bottom:solid black 1.0pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext 1.0pt;mso-border-bottom-alt:black .5pt;
  mso-border-right-alt:windowtext .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:25.4pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">S.N<o:p></o:p></span></b></p>
  </td>
  <td width="100" nowrap="" style="width:85.5pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black .5pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:25.4pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">TRAITS<o:p></o:p></span></b></p>
  </td>
  <td width="50" nowrap="" style="width:50pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black .5pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:25.4pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">ATTRIBUTES<o:p></o:p></span></b></p>
  </td>
  <td width="50" valign="top" style="width:72.0pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black .5pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:25.4pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></b></p>
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">POINTS<o:p></o:p></span></b></p>
  </td>
  <td width="53" valign="top" style="width:67.5pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black .5pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:25.4pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></b></p>
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">SELF<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:solid windowtext 1.0pt;
  border-left:none;border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;
  mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:windowtext 1.0pt;
  mso-border-left-alt:windowtext .5pt;mso-border-bottom-alt:black .5pt;
  mso-border-right-alt:black .5pt;mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;
  height:25.4pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></b></p>
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-size:
  9.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">APPRAISER<o:p></o:p></span></b></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:1;height:35.05pt">
  <td width="39" rowspan="5" style="width:23.25pt;border-top:none;border-left:solid windowtext 1.0pt;
  border-bottom:solid black 1.0pt;border-right:solid windowtext 1.0pt;
  mso-border-left-alt:solid windowtext 1.0pt;mso-border-bottom-alt:solid black .5pt;
  mso-border-right-alt:solid windowtext .5pt;padding:0cm 5.4pt 0cm 5.4pt;
  height:35.05pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">1<o:p></o:p></span></p>
  </td>
  <td width="143" rowspan="5" style="width:85.5pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
  solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:
  windowtext;mso-border-left-alt:windowtext;mso-border-bottom-alt:black;
  mso-border-right-alt:black;mso-border-style-alt:solid;mso-border-width-alt:
  .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:35.05pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Job
  Knowledge &amp; Functional Competency&nbsp; <o:p></o:p></span></p>
  </td>
  <td width="100" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.05pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Functional
  competency is very good and very strong in Knowledge.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.05pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">5<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.05pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.05pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:2;height:35.5pt">
  <td width="100" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.5pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Functional
  competency is good and strong in Knowledge.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.5pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">4<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.5pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:35.5pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:3;height:21.55pt">
  <td width="100" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Functional
  competency is fair and fair in Knowledge.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.55pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">3<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:21.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:4;height:34.6pt">
  <td width="100" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:34.6pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Functional
  competency is Average and average in Knowledge.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:34.6pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">2<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:34.6pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:34.6pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:5;height:30.55pt">
  <td width="100" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:30.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Functional
  competency is low and below average in Knowledge.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:30.55pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">1<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:30.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:30.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:6;height:48.55pt">
  <td width="39" nowrap="" rowspan="5" style="width:23.25pt;border-top:none;
  border-left:solid windowtext 1.0pt;border-bottom:solid black 1.0pt;
  border-right:solid windowtext 1.0pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-top-alt:windowtext .5pt;mso-border-left-alt:windowtext 1.0pt;
  mso-border-bottom-alt:black .5pt;mso-border-right-alt:windowtext .5pt;
  mso-border-style-alt:solid;padding:0cm 5.4pt 0cm 5.4pt;height:48.55pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">2<o:p></o:p></span></p>
  </td>
  <td width="143" rowspan="5" style="width:85.5pt;border-top:none;border-left:none;
  border-bottom:solid black 1.0pt;border-right:solid black 1.0pt;mso-border-top-alt:
  solid windowtext .5pt;mso-border-left-alt:solid windowtext .5pt;mso-border-top-alt:
  windowtext;mso-border-left-alt:windowtext;mso-border-bottom-alt:black;
  mso-border-right-alt:black;mso-border-style-alt:solid;mso-border-width-alt:
  .5pt;padding:0cm 5.4pt 0cm 5.4pt;height:48.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Willingness
  to accept&nbsp; Challenges and Capability of
  problem solving<o:p></o:p></span></p>
  </td>
  <td width="100" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:48.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Consistantly
  Accepts Challenges, and highly capable of solving the Problems permanently by
  evolving systems at all times.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:48.55pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">5<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:48.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:48.55pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:7;height:40.9pt">
  <td width="100" nowrap="" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:40.9pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Accepts
  Challenges, and Capable of solving the Problems permanently most of the
  times. <o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:40.9pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">4<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:40.9pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:40.9pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:8;height:44.5pt">
  <td width="100" nowrap="" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:44.5pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Accepts
  Challenges under pressure of immediate superior, and Capable of solving the
  Problems.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:44.5pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">3<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:44.5pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:44.5pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:9;height:50.35pt">
  <td width="100" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:50.35pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Unwillingly
  accepts challenges under pressure, and capable of solving the Problems for
  the time being. <o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:50.35pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">2<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:50.35pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:50.35pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
 <tr style="mso-yfti-irow:10;mso-yfti-lastrow:yes;height:38.2pt">
  <td width="100" nowrap="" style="width:100pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:38.2pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-size:10.0pt;font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">Lack
  of acceptance to take challenges, and having less capability of problem
  solving.<o:p></o:p></span></p>
  </td>
  <td width="120" style="width:72.0pt;border-top:none;border-left:none;
  border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:38.2pt">
  <p class="MsoNormal" align="center" style="margin-bottom:0cm;margin-bottom:.0001pt;
  text-align:center;line-height:normal"><b><span lang="EN-US" style="font-family:
  &quot;Arial&quot;,&quot;sans-serif&quot;">1<o:p></o:p></span></b></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:38.2pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
  <td width="113" valign="top" style="width:67.5pt;border-top:none;border-left:
  none;border-bottom:solid windowtext 1.0pt;border-right:solid black 1.0pt;
  mso-border-top-alt:solid windowtext .5pt;mso-border-top-alt:solid windowtext .5pt;
  mso-border-bottom-alt:solid windowtext .5pt;mso-border-right-alt:solid black .5pt;
  padding:0cm 5.4pt 0cm 5.4pt;height:38.2pt">
  <p class="MsoNormal" style="margin-bottom:0cm;margin-bottom:.0001pt;line-height:
  normal"><span lang="EN-US" style="font-family:&quot;Arial&quot;,&quot;sans-serif&quot;">&nbsp;</span></p>
  </td>
 </tr>
</tbody></table>
	

      </div>
    </div>

    <div id="page3" class="tab-pane fade">
      <div class="form-group">
	<textarea name="progress2" id="progress2" cols="5" rows="5" class="summernote form-control" required=""><?php echo isset($progress2) ? $progress2 : '' ?></textarea>
	</div>
    </div>

    <div id="page4" class="tab-pane fade">
     <div class="form-group">
	<textarea name="progress3" id="progress3" cols="5" rows="5" class="summernote form-control" required=""><?php echo isset($progress3) ? $progress3 : '' ?></textarea>
	</div>
    </div>

  </div>
</div>

</body>
</html>

<script>
	$(document).ready(function(){
	$('.summernote').summernote({
        height: 200,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
            [ 'view', [ 'undo', 'redo', 'fullscreen', 'codeview', 'help' ] ]
        ]
    })
     $('.select2').select2({
	    placeholder:"Please select here",
	    width: "100%"
	  });
     })
    $('#manage-progress').submit(function(e){
    	e.preventDefault()
    	start_load()
    	if($('#progress').val() == ''){
    		alert_toast("Please fill the progress description first",'error');
    		end_load();
    		return false;
    	}
    	$.ajax({
    		url:'ajax.php?action=save_progress',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				if(resp == 1){
					alert_toast('Data successfully saved',"success");
					setTimeout(function(){
						location.reload()
					},1500)
				}
			}
    	})
    })
</script>
