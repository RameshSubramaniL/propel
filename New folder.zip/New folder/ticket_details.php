<?php include 'db_connect.php' ?>
<div class="col-lg-12">
    <div class="row">
    <div class="col-lg-9">
    <?php
    $cat_qry = $conn1->query("SELECT * FROM `tickets` where id={$_GET['id']}");
    $row = $cat_qry->fetch_array();
    $ticket_assign = $row['assigned_to'];
    $emp = $conn->query("SELECT * FROM `employee_list` where employee_id={$row['req_by']}");
    $row1 = $emp->fetch_array();
    if($row['assigned_to'] != ""):
    //echo "SELECT employee_id,concat(firstname,' ',lastname) as name FROM `employee_list` where employee_id={$row['assigned_to']}";
    $as = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM `employee_list` where employee_id={$row['assigned_to']}");
    $row2 = $as->fetch_array();
    endif;
    ?>
	<div class="card card-outline card-primary">
		<div class="card-header" style="background:#386183;color:white;"><b><i class="fa fa-calendar"></i>&nbsp;&nbsp;&nbsp;<?php $dept = $conn->query("SELECT * FROM department_list where id='".$row['department']."' "); 
							$deptdata=$dept->fetch_assoc();
							echo $deptdata['department'] ?></b>
			<div class="card-tools">
                <b style="color:white;font-size:18px;">PROTKT<?=$row['id']?></b>&nbsp;&nbsp;&nbsp;
			</div>
		</div>
		<div class="card-body">
        <form action="" method="post">
        <ul class="list-group">  
                            <li class="list-group-item" style="padding: 10px;text-align: left;
    border: 1px solid #ffc;
    background: #ebebe6;border-left:3px solid orange;<?php if($row['status'] == 2) { echo "color:green"; }?>">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Note : </b><?php if($row['status'] == 0) { echo "Ticket till not assigned"; } elseif($row['status'] == 1) { echo "Ticket assigned to ".$row2['name']; } elseif($row['status'] == 2) { echo "Ticket Resolved on ".date('d-m-Y',strtotime($row['resolve_date']))." ".date('h:i a',strtotime($row['resolve_time'])) ; } ?>
                            </li>                         
                            <li class="list-group-item d-flex" style="background:aliceblue;">
                                <div class="col-auto flex-grow-1">
                                    <b><?php echo $row['description'] ?></b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                <i class="fa fa-user" style="font-size:20px;"></i>&nbsp;<b style="color:green;"><?=$row1['firstname']?> <?=$row1['lastname']?></b>&nbsp;- <?=$row['date_created'] ?>
                                </div>
                            </li>
                            <?php
                            $rep = $conn1->query("SELECT * FROM `ticket_replies` where ticket_id='{$_GET['id']}'");
                            if($rep->num_rows != 0)
                            {
                            while($rep_row = $rep->fetch_array()) {
                                $emp1 = $conn->query("SELECT * FROM `employee_list` where employee_id={$rep_row['rep_by']}");
                                $row2 = $emp1->fetch_array();
                            ?>
                            <li class="list-group-item d-flex" style="background:;">
                                <div class="col-auto flex-grow-1">
                                    <b><?php echo "".$rep_row['reply'] ?></b>
                                </div>
                                <div class="col-auto d-flex justify-content-end" style="font-size: 13px;">
                                <i class='fa fa-reply' style='color:#3f51b5;'></i>&nbsp;<b><?=$row2['firstname']?> <?=$row2['lastname']?></b> - <?=$rep_row['date_created']?>
                                </div>
                            </li>
                            <?php } } ?>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <label>Write Your Comments Here!</label>
                                <textarea name="reply" id="reply" cols="10" rows="1" class="form-control rounded-0 summernote" data-placeholder="Write the Roles & Responsibilities here." data-height="40vh" required><?php echo isset($content) ? $content : '' ?></textarea>

                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                </div>
                            </li>
                            <li class="list-group-item" style="text-align: center;">
                                <button type="submit" name="submit" class="btn btn-success">Submit Reply</button>
                            </li>
                           
        </ul>
        </form>
		</div></div>
	</div>
    <div class="col-lg-3">

	<div class="card card-outline card-primary">
		<div class="card-header"><b>Ticket Status</b>
			<!-- <div class="card-tools">
				<a class="btn btn-block btn-sm btn-default btn-flat border-primary new_designation" href="javascript:void(0)"><i class="fa fa-print"></i> Print</a>
			</div> -->
		</div>
		<div class="card-body">
        <ul class="list-group">
        <?php if($row['status'] == 0 && $_SESSION['login_type'] != 0) { ?>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                <?php if($_SESSION['login_type'] == 2) { ?>    
                                <b><button class="btn btn-info" id="sel" data-id="<?php echo $row['id'] ?>"><a href="#" style="color:white;">Assign ticket to me</a></button> </b>
                            <?php } else { ?> 
                                <b><button class="btn btn-info" id="oth"><a href="#" style="color:white;">Assign ticket</a></button> </b>
   
                            <?php } ?>
                            </div>
                               
                            </li>
        <?php } ?>
        <?php if($row['assigned_to'] == $_SESSION['login_employee_id']):?>
                            <center><a href="#" class="update_status" data-id="<?=$row['id']?>">Update status of the ticket</a></center>
        <?php endif; ?>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Ticket Status</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                <b style="color:white; padding:5px; <?php if($row['status'] == 0) { ?>background:#f15c53!important<?php } elseif($row['status'] == 1) { ?>background:orange!important<?php } elseif($row['status'] == 2) { ?>background:green!important<?php }?>"><?php if($row['status'] == 0) { echo "Not Assigned"; } else if($row['status'] == 1) { echo "Assigned"; } else if($row['status'] == 2) { echo "Resolved"; } ?></b><br>
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Category</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    <?php   $categ = $conn1->query("SELECT * FROM category_list where id='".$row['category']."' "); 
                        $categdata=$categ->fetch_assoc();
                        echo $categdata['category'] ?>
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Sub-Category</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                <?php $Scateg = $conn1->query("SELECT * FROM sub_category where id='".$row['sub_category']."' "); 
                        $Scategdata=$Scateg->fetch_assoc();
                        echo $Scategdata['sub_category'] ?>
                                </div>
                            </li>
                            <?php if($ticket_assign != ''): ?>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Assigned To</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                <?php
                                 $e = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM employee_list where employee_id={$ticket_assign}"); 
              $row1=$e->fetch_assoc();
               echo $row1['name'];  ?>
                                </div>
                            </li>
                        <?php endif; ?>
                        </ul>
		</div></div>
        <div class="card card-outline card-primary">
		<div class="card-header"><b>Ticket Details</b>
			<div class="card-tools">
			</div>
		</div>
		<div class="card-body">
        <ul class="list-group">
                           
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Ticket Id</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    PROTKT<?=$row['id']?>
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Ticket No</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                <?=$row['id']?>
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Created On</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                <?=$row['date_created']?>
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Updated On</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    ddd
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Replies</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    <?=$rep->num_rows?>
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                <b>Time Worked</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    0
                                </div>
                            </li>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <b>Due Date</b>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    0
                                </div>
                            </li>
                            
                           
                        </ul>
		</div></div>
	</div>
    </div>
</div>
<script>
	$(document).ready(function(){
		$('#list').dataTable()
        $('.summernote').summernote({
        height: 150,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
			['insert', ['link', 'picture', 'video']],
            [ 'view', [ 'undo', 'redo', 'fullscreen', 'codeview', 'help' ] ]
			
        ]
    })
	})
		$('.new_department').click(function(){
			uni_modal("New Category","manage_department.php")
		})
        $('.new_designation').click(function(){
			uni_modal("New Sub Category","manage_designation.php")
		})
		$('.manage_department').click(function(){
			uni_modal("Manage Department","manage_department.php?id="+$(this).attr('data-id'))
		})
        $('.edit_department').click(function(){
            uni_modal('Edit Department Details',"manage_department.php?id="+$(this).attr('data-id'))
        })
        $('.view_department').click(function(){
            uni_modal('Department Details',"view_department.php?id="+$(this).attr('data-id'))
        })
        $('.update_status').click(function(){
            uni_modal('Ticket Status Details',"update_status.php?id="+$(this).attr('data-id'))
        })
       
	$('#sel').click(function(){
	_conf("Are you sure to assign this ticket?","self_assign",[$(this).attr('data-id')])
	})
	function self_assign($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=self_assign',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Ticket Assigned Successfully",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>
<?php
if(isset($_POST['submit']))
{
    unset($_POST['submit']);unset($_POST['files']);
    extract($_POST);
    $data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
        $data .= ", rep_by = {$_SESSION['login_employee_id']} ";
		$data .= ", ticket_id = {$_GET['id']} ";
        //echo "INSERT INTO ticket_replies set $data";
		$save = $conn1->query("INSERT INTO ticket_replies set $data");		
		if ($save) {
            ?>
            <script type="text/javascript">
                setTimeout(function () {
                    window.location.href = 'index.php?page=ticket_details&id=<?php echo $_GET['id']; ?>';
                }, 1000);
            </script>
            <?php
        }
}

?>