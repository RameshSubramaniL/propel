$(document).ready(function(){
	$('#sortable').Tabledit({
		deleteButton: false,
		editButton: false,   		
		columns: {
		  identifier: [0, 'id'],                    
		  editable: [[2, 'activities'], [3, 'kpi'], [4, 'uom'], [5, 'ly_actual'], [6, 'ytd_target'], [7, 'growth_ly']]
		},
		hideIdentifier: true,
		url: 'live_edit.php'		
	});
});