<?php include'db_connect.php' ?>
<div class="col-lg-12">
    <div class="row">
    <div class="col-lg-6">

	<div class="card card-outline card-primary">
		<div class="card-header"><b>Category</b>
			<div class="card-tools">
				<a class="btn btn-block btn-sm btn-default btn-flat border-primary new_department" href="javascript:void(0)"><i class="fa fa-plus"></i> Add New</a>
			</div>
		</div>
		<div class="card-body">
        <ul class="list-group">
                            <?php 
                            $cat_qry = $conn1->query("SELECT * FROM `category_list` order by `id` desc");
                            while($row = $cat_qry->fetch_array()):
                            ?>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <?php echo $row['category'] ?>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    <!-- <a href="javascript:void(0)" class="view_department btn btn-sm btn-info text-light bg-gradient py-0 px-1 me-1" title="View Department Details" data-id="<?php echo $row['id'] ?>" ><span class="fa fa-th-list"></span></a> -->
                                    <a href="javascript:void(0)" class="edit_category btn btn-sm btn-primary bg-gradient py-0 px-1 me-1" title="Edit Department Details" data-id="<?php echo $row['id'] ?>"  data-name="<?php echo $row['name'] ?>"><span class="fa fa-edit"></span></a>
                                    <!-- <a href="javascript:void(0)" class="delete_department btn btn-sm btn-danger bg-gradient py-0 px-1" title="Delete Department" data-id="<?php echo $row['department_id'] ?>"  data-name="<?php echo $row['name'] ?>"><span class="fa fa-trash"></span></a> -->
                                </div>
                            </li>
                            <?php endwhile; ?>
                            <?php if($cat_qry->num_rows == 0): ?>
                                <li class="list-group-item text-center">No data listed yet.</li>
                            <?php endif; ?>
                        </ul>
		</div></div>
	</div>
    <div class="col-lg-6">

	<div class="card card-outline card-primary">
		<div class="card-header"><b>Sub-Category</b>
			<div class="card-tools">
				<a class="btn btn-block btn-sm btn-default btn-flat border-primary new_designation" href="javascript:void(0)"><i class="fa fa-plus"></i> Add New</a>
			</div>
		</div>
		<div class="card-body">
        <ul class="list-group">
                            <?php 
                            $cat_qry = $conn1->query("SELECT * FROM `sub_category` order by id desc");
                            while($row = $cat_qry->fetch_array()):
                            ?>
                            <li class="list-group-item d-flex">
                                <div class="col-auto flex-grow-1">
                                    <?php echo $row['sub_category'] ?>
                                </div>
                                <div class="col-auto d-flex justify-content-end">
                                    <!-- <a href="javascript:void(0)" class="view_designation btn btn-sm btn-info text-light bg-gradient py-0 px-1 me-1" title="View Designation Details" data-id="<?php echo $row['id'] ?>" ><span class="fa fa-th-list"></span></a> -->
                                    <a href="javascript:void(0)" class="edit_scategory btn btn-sm btn-primary bg-gradient py-0 px-1 me-1" title="Edit Designation Details" data-id="<?php echo $row['id'] ?>"  data-name="<?php echo $row['name'] ?>"><span class="fa fa-edit"></span></a>
                                    <!-- <a href="javascript:void(0)" class="delete_designation btn btn-sm btn-danger bg-gradient py-0 px-1" title="Delete Designation" data-id="<?php echo $row['id'] ?>"  data-name="<?php echo $row['name'] ?>"><span class="fa fa-trash"></span></a> -->
                                </div>
                            </li>
                            <?php endwhile; ?>
                            <?php if($cat_qry->num_rows == 0): ?>
                                <li class="list-group-item text-center">No data listed yet.</li>
                            <?php endif; ?>
                        </ul>
		</div></div>
	</div>
    </div>
</div>
<script>
	$(document).ready(function(){
		$('#list').dataTable()
	})
		$('.new_department').click(function(){
			uni_modal("New Category","manage_department.php")
		})
        $('.new_designation').click(function(){
			uni_modal("New Sub Category","manage_designation.php")
		})
		$('.manage_department').click(function(){
			uni_modal("Manage Department","manage_department.php?id="+$(this).attr('data-id'))
		})
        $('.edit_category').click(function(){
            uni_modal('Edit Category Details',"manage_department.php?id="+$(this).attr('data-id'))
        })
        $('.edit_scategory').click(function(){
            uni_modal('Edit Sub-Category Details',"manage_SCategory.php?id="+$(this).attr('data-id'))
        })
        $('.view_department').click(function(){
            uni_modal('Department Details',"view_department.php?id="+$(this).attr('data-id'))
        })
       
	$('.delete_department').click(function(){
	_conf("Are you sure to delete this Department?","delete_department",[$(this).attr('data-id')])
	})
	function delete_department($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_department',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>