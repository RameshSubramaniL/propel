<?php include('db_connect.php'); ?>
<?php
//print_r($_SESSION);
//echo $_SERVER['PHP_SELF'];
$twhere ="";
if($_SESSION['login_type'] != 1)
  $twhere = "  ";
?>
<!-- Info boxes -->
<style>
table.dataTable tr th.select-checkbox.selected::after {
    content: "✔";
    margin-top: -11px;
    margin-left: -4px;
    text-align: center;
    text-shadow: rgb(176, 190, 217) 1px 1px, rgb(176, 190, 217) -1px -1px, rgb(176, 190, 217) 1px -1px, rgb(176, 190, 217) -1px 1px;
}

.blink-bg {
    color: #fff;
    padding: 10px;
    /* display: inline-block; */
    border-radius: 5px;
    animation: blinkingBackground 2s infinite;
}

@keyframes blinkingBackground {
    0% {
        background-color: red;
    }

    25% {
        background-color: #fff;
    }

    50% {
        background-color: red;
    }

    75% {
        background-color: #fff;
    }

    100% {
        background-color: #fff;
    }
}
</style>
<?php if($_SESSION['login_type'] == 2): ?>
<div class="row">
    <a href="index.php?page=home&&st=0">
        <div class="col-12 col-sm-6 col-md-2">
            <div class="small-box bg-light shadow-sm"
                style="<?php if($_GET['st'] == 0) { ?>border: 3px solid #2196f3; <?php } else { ?>border:1px solid #2196f3 <?php } ?>">
                <div class="inner">

                    <p style="color:#2196f3"><i class="fa fa-calendar" aria-hidden="true"
                            style="font-size:22px;"></i>&nbsp;Open
                        Tickets&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets where status=0")->num_rows;  ?></b>
                    </p>
                </div>

            </div>
    </a>
</div>
<a href="index.php?page=home&&st=1">
    <div class="col-12 col-sm-6 col-md-2">
        <div class="small-box bg-light shadow-sm"
            style="<?php if($_GET['st'] == 1 && !isset($_GET['k'])) { ?>border: 3px solid gray; <?php } else { ?>border:1px solid gray <?php } ?>">
            <div class="inner">
                <p style="color:gray"><i class="fa fa-calendar" aria-hidden="true"
                        style="font-size:22px;"></i>&nbsp;Assign to
                    Me&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets where status=1 and assigned_to = {$_SESSION['login_employee_id']}")->num_rows; ?></b>
                </p>
            </div>

        </div>
</a>
</div>
<a href="index.php?page=home&&st=1&&k">
    <div class="col-12 col-sm-6 col-md-2">
        <div class="small-box bg-light shadow-sm"
            style="<?php if($_GET['st'] == 1 && isset($_GET['k'])) { ?>border: 3px solid blue; <?php } else { ?>border:1px solid blue <?php } ?>">
            <div class="inner">
                <p style="color:blue"><i class="fa fa-calendar" aria-hidden="true"
                        style="font-size:22px;"></i>&nbsp;Assign to
                    Others&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets where status=1 and assigned_to != {$_SESSION['login_employee_id']}")->num_rows; ?></b>
                </p>
            </div>

        </div>
</a>
</div>
<!-- <a href="index.php?page=home&&st=0">
          <div class="col-12 col-sm-6 col-md-2">
            <div class="small-box bg-light shadow-sm" style="<?php if($_GET['st'] == 0) { ?>border: 3px solid orange; <?php } else { ?>border:1px solid orange <?php } ?>">
              <div class="inner">

                <p style="color:orange"><i class="fa fa-calendar" aria-hidden="true" style="font-size:22px;"></i>&nbsp;Unassigned&nbsp;&nbsp;<b><?php echo $conn->query("SELECT * FROM employee_list where doe='0000-00-00'")->num_rows; ?></b></p>
              </div>
             
            </div></a>
          </div> -->
<a href="index.php?page=home&&st=2">
    <div class="col-12 col-sm-6 col-md-3">
        <div class="small-box bg-light shadow-sm"
            style="<?php if($_GET['st'] == 2) { ?>border: 3px solid green; <?php } else { ?>border:1px solid green <?php } ?>">
            <div class="inner">

                <p style="color:green"><i class="fa fa-calendar" aria-hidden="true"
                        style="font-size:22px;"></i>&nbsp;Closed
                    Tickets&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets where status=2")->num_rows; ?></b>
                </p>
            </div>
        </div>
</a>
</div>

<a href="index.php?page=home&&st=3">
    <div class="col-12 col-sm-6 col-md-3">
        <div class="small-box bg-light shadow-sm"
            style="<?php if($_GET['st'] == 3) { ?>border: 3px solid red; <?php } else { ?>border:1px solid red <?php } ?>">
            <?php $s = $conn1->query("SELECT * FROM tickets WHERE assigned_date < NOW() - INTERVAL 1 DAY")->num_rows;  ?>
            <div class="inner <?php if($s != 0) { echo"blink-bg"; } ?>">

                <p style="color:red"><i class="fa fa-calendar" aria-hidden="true"
                        style="font-size:22px;"></i>&nbsp;Overdue&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets WHERE assigned_date < NOW() - INTERVAL 1 DAY  AND resolve_date is null")->num_rows; ?></b>
                </p>
            </div>

        </div>
</a>
</div>


</div>
</div>
<script type="text/javascript" src="assets/TableCheckAll.js"></script>
<form action="" method="POST">

    <table class="table tabe-hover table-bordered" id="example">
        <thead>
            <tr>
                <th><input type="checkbox" class="check-all-users"></th>
                <th>S.No</th>
                <th>Ticket No</th>
                <th>Ticket Date</th>
                <th>Request By</th>
                <th>Dapartment</th>
                <th>Category</th>
                <th>Sub-Category</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
					$i = 1;
          if(isset($_GET['st']))
          {
            if($_GET['st'] == 3)
            {
            $qry = $conn1->query("SELECT * FROM tickets WHERE assigned_date < NOW() - INTERVAL 1 DAY AND resolve_date is null");
            }
            else if($_GET['st'] == 0) {
              $qry = $conn1->query("SELECT * FROM tickets where status=0 order by id desc");
            } 
            else if($_GET['st'] == 1 && !isset($_GET['k'])) {
            $qry = $conn1->query("SELECT * FROM tickets where status='{$_GET['st']}' and assigned_to = {$_SESSION['login_employee_id']} order by id desc");
            } 
            else if($_GET['st'] == 1 && isset($_GET['k'])) {
              $qry = $conn1->query("SELECT * FROM tickets where status='{$_GET['st']}' and assigned_to != {$_SESSION['login_employee_id']} order by id desc");
              } 
              else if($_GET['st'] == 2) {
                $qry = $conn1->query("SELECT * FROM tickets where status=2 order by id desc");
              }            
          } 
					while($row= $qry->fetch_assoc()):
					?>
            <tr <?php if($_GET['st'] == 0) { ?>style="background:#2196f3!important"
                <?php } elseif($_GET['st'] == 1 && !isset($_GET['k'])) { ?>style="background:#f1d092!important"
                <?php } elseif($_GET['st'] && isset($_GET['k'])) { ?>style="background:blue!important;color:white"
                <?php } elseif($_GET['st'] == 2) { ?>style="background:!important"
                <?php } elseif($_GET['st'] == 3) { ?>style="background:#E9847E;!important" <?php } ?>>
                <td><input type="checkbox" class="check-user" value="<?=$row['id']?>" name="ticket_no[]"></td>
                <th class="text-center"><?php echo $i++ ?></th>
                <td><a href="index.php?page=ticket_details&&id=<?php echo $row['id']; ?>"
                        style="text-decoration:underline;<?php if($_GET['st'] == 0 || ($_GET['st'] == 1 && isset($_GET['k']))) { echo "color:white"; }?>"><?php echo "PROTKT".$row['id'] ?></a>
                </td>
                <td><?php echo ucwords($row['date_created']) ?></td>
                <td><?php  $e = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM employee_list where employee_id={$row['req_by']}"); 
              $row1=$e->fetch_assoc();
               echo $row1['name'].'('.$row['req_by'].')'; ?></td>
                <td><?php $dept = $conn->query("SELECT * FROM department_list where id='".$row['department']."' "); 
							$deptdata=$dept->fetch_assoc();
							echo $deptdata['department'] ?></td>
                <td><b><?php  $categ = $conn1->query("SELECT * FROM category_list where id='".$row['category']."' "); 
                        $categdata=$categ->fetch_assoc();
                        echo $categdata['category'] ?></b></td>
                <td><?php $Scateg = $conn1->query("SELECT * FROM sub_category where id='".$row['sub_category']."' "); 
                        $Scategdata=$Scateg->fetch_assoc();
                        echo $Scategdata['sub_category'] ?></td>
                <!-- <td><?php echo $row['description'] ?></td> -->
                <td><b
                        style="color:white; padding:5px; <?php if($row['status'] == 0) { ?>background:#f15c53!important<?php } elseif($row['status'] == 1) { ?>background:orange!important<?php } elseif($row['status'] == 2) { ?>background:green!important<?php }?>"><?php if($row['status'] == 0) { echo "Not Assigned"; } else if($row['status'] == 1) { echo "Assigned"; } else if($row['status'] == 2) { echo "Resolved"; } ?></b>
                </td>

            </tr>
            <?php endwhile; ?>


        </tbody>
        <!-- <tfoot>
                <tr>
                  <th><input type="checkbox" class="check-user"></th>
                  <th>S.No</th>
                  <th>Ticket No</th>
                  <th>Ticket Date</th>
						      <th>Request By</th>
						      <th>Title</th>
                  <th>Category</th>
                  <th>Sub-Category</th>
                  <th>Status</th>
                  
                </tr>
                </tfoot> -->
    </table>
    <?php if(!isset($_GET['st']) || ($_GET['st'] == 0)): ?>
    <center>
        <div style="width:30%">
            Assign Selected ticket to : <select class="form-control" name="assign" required>
                <option value="">Please select Here</option>
                <?php
							$t = $conn1->query("SELECT * FROM team_list"); 
							while($row=$t->fetch_assoc()):
              $e = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM employee_list where employee_id={$row['employee_id']}"); 
              $row1=$e->fetch_assoc();
?>
                <option value="<?php echo $row1['employee_id'] ?>"><?=$row1['name'];?></option>
                <?php endwhile; ?>
            </select><br>
            <button class="btn btn-success" type="submit" name="save">Submit</button>
        </div>
    </center>
    <?php endif; ?>
</form>
<script>
$(document).ready(function() {
    let example = $('#example').DataTable({
        columnDefs: [{
            orderable: false,
            className: 'select-checkbox',
            targets: 0
        }],
        select: {
            style: 'os',
            selector: 'td:first-child'
        },
        order: [
            [1, 'asc']
        ]
    });
    example.on("click", "th.select-checkbox", function() {
        if ($("th.select-checkbox").hasClass("selected")) {
            example.rows().deselect();
            $("th.select-checkbox").removeClass("selected");
        } else {
            example.rows().select();
            $("th.select-checkbox").addClass("selected");
        }
    }).on("select deselect", function() {
        ("Some selection or deselection going on")
        if (example.rows({
                selected: true
            }).count() !== example.rows().count()) {
            $("th.select-checkbox").removeClass("selected");
        } else {
            $("th.select-checkbox").addClass("selected");
        }
    });
    $('#example').TableCheckAll({
        //alert();
        checkAllCheckboxClass: '.check-all-users',
        checkboxClass: '.check-user'
    });

    $('#top-websites-table').TableCheckAll();
});
</script>
<?php endif; ?>
<?php if($_SESSION['login_type'] == 0): ?>
<?php $id = $_SESSION['login_employee_id']; ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body">
                <div id="msg"></div>
                <form action="" id="manage_ticket">
                    <input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
                    <div class="row">
                        <div class="col-md-6 border-right">
                            <div class="form-group">
                                <label for="" class="control-label">Ticket Title <span
                                        style="color:red">*</span></label>
                                <input type="text" name="title" class="form-control form-control-sm" required
                                    value="<?php echo isset($employee_id) ? $employee_id : '' ?>">
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Category<span style="color:red">*</span></label>

                                <select name="category" id="category" class="form-control form-control-sm select2">
                                    <option value="">Select Category Here</option>
                                    <?php
								$cat = $conn1->query("SELECT * FROM category_list"); 
							while($row=$cat->fetch_assoc()):
							?>
                                    <option value="<?php echo $row['category'] ?>"
                                        <?php echo isset($department_id) && $department_id == $row['id'] ? 'selected' : '' ?>>
                                        <?php echo $row['category'] ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Sub-Category<span style="color:red">*</span></label>
                                <select name="sub_category" id="sub_category"
                                    class="form-control form-control-sm select2">
                                    <option value="">Select Sub-Category Here</option>
                                    <?php
								$scat = $conn1->query("SELECT * FROM sub_category"); 
							while($row=$scat->fetch_assoc()):
							?>
                                    <option value="<?php echo $row['sub-category'] ?>"
                                        <?php echo isset($department_id) && $department_id == $row['id'] ? 'selected' : '' ?>>
                                        <?php echo $row['sub-category'] ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="" class="control-label">Uploads</label>
                                <div class="custom-file">
                                    <input type="file" class="custom-file-input" id="customFile" name="uploads"
                                        onchange="displayImg(this,$(this))" multiple>
                                    <label class="custom-file-label" for="customFile">Choose file</label>
                                </div>
                            </div>


                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="" class="control-label">Problem Description <span
                                        style="color:red">*</span></label>
                                <textarea name="description" id="description" cols="10" rows="1"
                                    class="form-control rounded-0 summernote"
                                    data-placeholder="Write the Roles & Responsibilities here." data-height="40vh"
                                    required><?php echo isset($content) ? $content : '' ?></textarea>
                            </div>


                            <div class="form-group">

                                <div>
                                </div>
                            </div>
                            <hr>
                            <div class="col-lg-12 text-right justify-content-center d-flex">
                                <button class="btn btn-primary mr-2">Save</button>
                                <button class="btn btn-secondary" type="button"
                                    onclick="location.href = 'index.php?page=employee_list'">Cancel</button>
                            </div>
                </form>
            </div>
        </div>
    </div>
    <!--/.Carousel Wrapper-->

    <!--/.Carousel Wrapper-->

    <?php endif; ?>
    <?php if($_SESSION['login_type'] == 1): ?>
    <div class="row">
        <a href="index.php?page=home&&st=0">
            <div class="col-12 col-sm-6 col-md-3">
                <div class="small-box bg-light shadow-sm"
                    style="<?php if($_GET['st'] == 0) { ?>border: 3px solid #2196f3; <?php } else { ?>border:1px solid #2196f3 <?php } ?>">
                    <div class="inner">

                        <p style="color:#2196f3"><i class="fa fa-calendar" style="font-size:22px;"></i>&nbsp;Open
                            Tickets&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets where status=0")->num_rows;  ?></b>
                        </p>
                    </div>

                </div>
        </a>
    </div>

    <a href="index.php?page=home&&st=1">
        <div class="col-12 col-sm-6 col-md-3">
            <div class="small-box bg-light shadow-sm"
                style="<?php if($_GET['st'] == 1) { ?>border: 3px solid gray; <?php } else { ?>border:1px solid gray <?php } ?>">
                <div class="inner">
                    <p style="color:gray"><i class="fa fa-calendar" aria-hidden="true"
                            style="font-size:22px;"></i>&nbsp;No.Of.Tickets
                        Pending&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets where status=1 and assigned_to = {$_SESSION['login_employee_id']}")->num_rows;  ?></b>
                    </p>
                </div>

            </div>
    </a>
</div>
<!--
          <a href="index.php?page=home&&st=2">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="small-box bg-light shadow-sm" style="<?php if($_GET['st'] == 2) { ?>border: 3px solid green; <?php } else { ?>border:1px solid green <?php } ?>">
              <div class="inner">
                
                <p style="color:green"><i class="fa fa-calendar" aria-hidden="true" style="font-size:22px;"></i>&nbsp;Closed Tickets&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets where status=2 and assigned_to = {$_SESSION['login_employee_id']}")->num_rows; ?></b></p>
              </div>             
            </div></a>
          </div>
          <a href="index.php?page=home&&st=3">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="small-box bg-light shadow-sm " style="<?php if($_GET['st'] == 3) { ?>border: 3px solid red; <?php } else { ?>border:1px solid red <?php } ?>">
            <?php $s = $conn1->query("SELECT * FROM tickets WHERE assigned_date < NOW() - INTERVAL 1 DAY and assigned_to = {$_SESSION['login_employee_id']}")->num_rows;  ?>
            <div class="inner <?php if($s != 0) { echo"blink-bg"; } ?>">
                
                <p style="color:red"><i class="fa fa-calendar" aria-hidden="true" style="font-size:22px;"></i>&nbsp;Overdue&nbsp;&nbsp;<b><?php echo $conn1->query("SELECT * FROM tickets WHERE assigned_date < NOW() - INTERVAL 1 DAY and assigned_to = {$_SESSION['login_employee_id']}")->num_rows; ?></b></p>
              </div>
              
            </div></a>
          </div>
          
         
          </div>
      </div> -->
<script type="text/javascript" src="assets/TableCheckAll.js"></script>


<table class="table tabe-hover table-bordered" id="example">
    <thead>
        <tr>
            <th><input type="checkbox" class="check-all-users"></th>
            <th>S.No</th>
            <th>Ticket No</th>
            <th>Ticket Date</th>
            <th>Request By</th>
            <th>Department</th>
            <th>Category</th>
            <th>Sub-Category</th>
            <!-- <th>Status</th> -->

            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
					$i = 1;
          if(isset($_GET['st']))
          {
            if($_GET['st'] == 3)
            {
            $qry = $conn1->query("SELECT * FROM tickets WHERE assigned_date < NOW() - INTERVAL 1 DAY and assigned_to = {$_SESSION['login_employee_id']}");
            }
            else if($_GET['st'] == 0) {
              $qry = $conn1->query("SELECT * FROM tickets where status=0 order by id desc");
              } else {
            $qry = $conn1->query("SELECT * FROM tickets where status='{$_GET['st']}' and assigned_to = {$_SESSION['login_employee_id']} order by id desc");
            }
          } 
					while($row= $qry->fetch_assoc()):
					?>
        <tr <?php if($_GET['st'] == 0) { ?>style="background:#2196f3!important"
            <?php } elseif($_GET['st'] == 1) { ?>style="background:#f1d092!important"
            <?php } elseif($_GET['st'] == 2) { ?>style="background:!important"
            <?php } elseif($_GET['st'] == 3) { ?>style="background:#E9847E; !important" <?php } ?>>
            <td>
                <input type="checkbox" class="check-user">
            </td>
            <th class="text-center"><?php echo $i++ ?></th>
            <td>
                <?php if($row['assigned_to']!='') { ?>
                <a href="index.php?page=ticket_details&&id=<?php echo $row['id']; ?>"
                    style="text-decoration:underline;<?php if($_GET['st'] == 0) { echo "color:white"; } ?>"><?php echo "PROTKT".$row['id'] ?></a>
                <?php } else { 
                  echo "PROTKT".$row['id']; 
                  }?>
            </td>
            <td>
                <?php echo ucwords($row['date_created']) ?>
            </td>
            <td>
                <?php 
                $e = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM employee_list where employee_id={$row['req_by']}"); 
              $row1=$e->fetch_assoc();
               echo $row1['name'].'('.$row['req_by'].')'; ?>
            </td>
            <td><?php $dept = $conn->query("SELECT * FROM department_list where id='".$row['department']."' "); 
							$deptdata=$dept->fetch_assoc();
							echo $deptdata['department']; ?></td>
            <td><b><?php
                        $categ = $conn1->query("SELECT * FROM category_list where id='".$row['category']."' "); 
                        $categdata=$categ->fetch_assoc();
                        echo $categdata['category']
                         ?></b></td>
            <td><?php 
                        $Scateg = $conn1->query("SELECT * FROM sub_category where id='".$row['sub_category']."' "); 
                        $Scategdata=$Scateg->fetch_assoc();
                        echo $Scategdata['sub_category'] ?></td>
            <!-- <td><?php echo $row['description'] ?></td> -->
            <td>
                <b
                    style="color:white; padding:5px; <?php if($row['status'] == 1) { ?>background:orange!important<?php } elseif($row['status'] == 2) { ?>background:green!important<?php }?>">
                    <?php 
                              if($row['status'] == 0) 
                              { ?>
                              <b><button class="btn btn-info sel-btn" data-id="<?php echo $row['id'] ?>">Assign ticket to me</button></b>

                    <!-- <b><button class="btn btn-info" id="sel" data-id="<?php echo $row['id'] ?>"><a href="#"
                                style="color:white;">Assign ticket to me</a></button> </b> -->
                    <?php 
                              } else if($row['status'] == 1) 
                              {  
                                $e = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM employee_list where employee_id={$row['assigned_to']}"); 
                                $row4=$e->fetch_assoc();
                                echo "Assigned To ".$row4['name']; 
                              } else if($row['status'] == 2) 
                              { 
                                echo "Resolved"; 
                              } 
                              ?>
                </b>
            </td>

        </tr>
        <?php endwhile; ?>


    </tbody>
    <!-- <tfoot>
                <tr>
                  <th><input type="checkbox" class="check-user"></th>
                  <th>S.No</th>
                  <th>Ticket No</th>
                  <th>Ticket Date</th>
						      <th>Request By</th>
						      <th>Title</th>
                  <th>Category</th>
                  <th>Sub-Category</th>
                  <th>Status</th>
                  
                </tr>
                </tfoot> -->
</table>
<?php if($_SESSION['login_type'] == 2):?>
<center>
    <div style="width:30%">
        Assign Selected ticket to : <select class="form-control" name="">
            <option>Please select Here</option>
        </select><br>
        <button class="btn btn-success" type="submit" name="submit">Submit</button>
    </div>
</center>
<?php endif; ?>
<script>
$(document).ready(function() {
    let example = $('#example').DataTable({
        columnDefs: [{
            orderable: false,
            className: 'select-checkbox',
            targets: 0
        }],
        select: {
            style: 'os',
            selector: 'td:first-child'
        },
        order: [
            [1, 'asc']
        ]
    });
    example.on("click", "th.select-checkbox", function() {
        if ($("th.select-checkbox").hasClass("selected")) {
            example.rows().deselect();
            $("th.select-checkbox").removeClass("selected");
        } else {
            example.rows().select();
            $("th.select-checkbox").addClass("selected");
        }
    }).on("select deselect", function() {
        ("Some selection or deselection going on")
        if (example.rows({
                selected: true
            }).count() !== example.rows().count()) {
            $("th.select-checkbox").removeClass("selected");
        } else {
            $("th.select-checkbox").addClass("selected");
        }
    });
    $('#example').TableCheckAll({
        //alert();
        checkAllCheckboxClass: '.check-all-users',
        checkboxClass: '.check-user'
    });

    $('#top-websites-table').TableCheckAll();
});

$('#sel').click(function() {
    _conf("Are you sure to assign this ticket?", "self_assign", [$(this).attr('data-id')])
})

function self_assign($id) {
    start_load()
    $.ajax({
        url: 'ajax.php?action=self_assign',
        method: 'POST',
        data: {
            id: $id
        },
        success: function(resp) {
            if (resp == 1) {
                alert_toast("Ticket Assigned Successfully", 'success')
                setTimeout(function() {
                    location.reload()
                }, 1500)

            }
        }
    })
}
</script>
<script>
$(document).ready(function() {
    $('.sel-btn').click(function() {
        var ticketId = $(this).attr('data-id');
        _conf("Are you sure to assign this ticket?", "self_assign", [ticketId]);
    });

    function self_assign(ticketId) {
        start_load();
        $.ajax({
            url: 'ajax.php?action=self_assign',
            method: 'POST',
            data: {
                id: ticketId
            },
            success: function(resp) {
                if (resp == 1) {
                    alert_toast("Ticket Assigned Successfully", 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1500);
                }
            }
        });
    }
});
</script>
<?php endif; ?>



<?php if($_SESSION['login_type'] == 3): ?>
<?php $id = $_SESSION['login_id']; 
  ?>

<div class="row">
    <a
        href="index.php?page=view_task_report&&st=1&&<?php if(isset($_GET['year'])) { ?>year=<?=$_GET['year']?>&&quarter=<?=$_GET['quarter']?><?php } ?>">
        <div class="col-12 col-sm-6 col-md-2">
            <div class="small-box bg-light shadow-sm border">
                <div class="inner">
                    <?php
                if(isset($_GET['submit']))
                { ?>
                    <h3><?php 
                if($_GET['quarter'] != "")
                { 
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']} and pperiod='{$_GET['quarter']}'";
                }
                else{
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']}"; 
                }
                echo $conn->query("SELECT t.* FROM task_list t inner join employee_list e on e.employee_id = t.employee_id inner join department_list d on e.department_id = d.id $where and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                    <?php }
                else
                {
                ?>
                    <h3><?php 
                $where = " where e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}";
                echo $conn->query("SELECT t.* FROM task_list t inner join employee_list e on e.employee_id = t.employee_id inner join department_list d on e.department_id = d.id $where and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                    <?php
                }
                ?>

                    <p>Total Tasks</p>
                </div>
                <div class="icon">
                    <i class="fa fa-list" style="color:#1a31a370;font-size:20px;top:66px"></i>
                </div>
            </div>
    </a>
</div>
<a
    href="index.php?page=view_task_report&&st=2&&<?php if(isset($_GET['year'])) { ?>year=<?=$_GET['year']?>&&quarter=<?=$_GET['quarter']?><?php } ?>">
    <div class="col-12 col-sm-6 col-md-2">
        <div class="small-box bg-light shadow-sm border">
            <div class="inner">
                <?php
                if(isset($_GET['submit']))
                { ?>
                <h3><?php 
                if($_GET['quarter'] != "")
                { 
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']} and pperiod='{$_GET['quarter']}' ";
                }
                else
                {
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']}";

                }
                echo $conn->query("SELECT t.* FROM task_list t inner join employee_list e on e.employee_id = t.employee_id inner join department_list d on e.department_id = d.id $where and t.status=2 and t.status1=0 and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php }
                else
                {
                ?>
                <h3><?php 
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) ";
                echo $conn->query("SELECT t.* FROM task_list t inner join employee_list e on e.employee_id = t.employee_id inner join department_list d on e.department_id = d.id $where and t.status=2 and t.status1=0 and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php
                }
                ?>

                <p>To Be Evaluate </p>
            </div>
            <div class="icon">
                <i class="fa fa-check-square" style="color:#35b73570;font-size:20px;top:66px"></i>
            </div>
        </div>
</a>
</div>
<a
    href="index.php?page=view_task_report&&st=4&&<?php if(isset($_GET['year'])) { ?>year=<?=$_GET['year']?>&&quarter=<?=$_GET['quarter']?><?php } ?>">
    <div class="col-12 col-sm-6 col-md-2">
        <div class="small-box bg-light shadow-sm border">
            <div class="inner">
                <?php
                if(isset($_GET['submit']))
                { ?>
                <h3><?php
                if($_GET['quarter'] != "")
                { 
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']} and pperiod='{$_GET['quarter']}'";
                }
                else
                {
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']}";
                }
                echo $conn->query("SELECT t.* FROM task_list t left join employee_list e on e.employee_id = t.employee_id left join department_list d on e.department_id = d.id left join ratings r on t.id = r.task_id $where and t.status=2 and t.status1=1 and r.hod_per!=1 and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php }
                else
                {
                ?>
                <h3><?php
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) ";
                echo $conn->query("SELECT t.* FROM task_list t left join employee_list e on e.employee_id = t.employee_id left join department_list d on e.department_id = d.id left join ratings r on t.id = r.task_id $where and t.status=2 and t.status1=1 and r.hod_per=0 and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php
                }
                ?>
                <p>Evaluated Tasks</p>
            </div>
            <div class="icon">
                <i class="fa fa-check-square" style="color:#87b7eb;font-size:20px;top:66px"></i>
            </div>
        </div>
</a>
</div>
<a
    href="index.php?page=view_task_report&&st=3&&<?php if(isset($_GET['year'])) { ?>year=<?=$_GET['year']?>&&quarter=<?=$_GET['quarter']?><?php } ?>">
    <div class="col-12 col-sm-6 col-md-2">
        <div class="small-box bg-light shadow-sm border">
            <div class="inner">
                <?php
                if(isset($_GET['submit']))
                { ?>
                <h3><?php 
                if($_GET['quarter'] != "")
                { 
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']} and pperiod='{$_GET['quarter']}'";
                }
                else
                {
                  $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']}";
                }
                echo $conn->query("SELECT t.* FROM task_list t inner join employee_list e on e.employee_id = t.employee_id inner join department_list d on e.department_id = d.id $where and t.status!=2 and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php }
                else
                {
                ?>
                <h3><?php 
                $where = " where (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) ";
                echo $conn->query("SELECT t.* FROM task_list t inner join employee_list e on e.employee_id = t.employee_id inner join department_list d on e.department_id = d.id $where and t.status!=2 and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php
                }
                ?>

                <p>Pending Task </p>
            </div>
            <div class="icon">
                <i class="fa fa-exclamation" style="color:red;font-size:20px;top:66px"></i>
            </div>
        </div>
</a>
</div>
<a
    href="index.php?page=view_task_report&&st=5&&<?php if(isset($_GET['year'])) { ?>year=<?=$_GET['year']?>&&quarter=<?=$_GET['quarter']?><?php } ?>">
    <div class="col-12 col-sm-6 col-md-2">
        <div class="small-box bg-light shadow-sm border">
            <div class="inner">
                <?php
                if(isset($_GET['submit']))
                { ?>
                <h3><?php 
                if($_GET['quarter'] != "")
                { 
                $where = " where r.hod_per=1 and (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']} and pperiod='{$_GET['quarter']}'";
                }
                else
                {
                  $where = " where r.hod_per=1 and (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']}) and year_from={$_GET['year']}";

                }
                echo $conn->query("SELECT t.*,concat(e.firstname,' ',e.lastname) as name,d.department,r.hod_per FROM task_list t left join employee_list e on e.employee_id = t.employee_id left join department_list d on e.department_id = d.id left join ratings r on t.id = r.task_id $where and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php }
                else
                {
                ?>
                <h3><?php 
                $where = " where (r.hod_per=1 or r.hod_per=2) and (e.evaluator_id = '{$_SESSION['login_employee_id']}' or e.evaluator2_id = '{$_SESSION['login_employee_id']}' or t.employee_id = {$_SESSION['login_employee_id']})";
                echo $conn->query("SELECT t.*,concat(e.firstname,' ',e.lastname) as name,d.department,r.hod_per FROM task_list t left join employee_list e on e.employee_id = t.employee_id left join department_list d on e.department_id = d.id left join ratings r on t.id = r.task_id $where and e.doe='0000-00-00' order by unix_timestamp(t.date_created) asc")->num_rows;
                //echo $conn->query("SELECT * FROM task_list where employee_id=$id AND status=2")->num_rows; ?></h3>
                <?php
                }
                ?>


                <p>Completed Task</p>
            </div>
            <div class="icon">
                <i class="fa fa-check-square" style="color:#35b73570;font-size:20px;top:66px"></i>
            </div>
        </div>
</a>
</div>
<a href="index.php?page=view_mp_report&&st=1">
    <div class="col-12 col-sm-6 col-md-2">
        <div class="small-box bg-light shadow-sm border">
            <div class="inner">
                <h3><?php echo $conn->query("select a.employee_id, concat(a.firstname,' ',a.lastname) as name,b.department,b.description,c.designation,concat(d.firstname,' ',d.lastname) as Evaluator_Name from employee_list a, department_list b,designation_list c,employee_list d where a.department_id = b.id and a.designation_id=c.id and a.evaluator_id=d.employee_id and a.doe='0000-00-00' and a.employee_id!={$_SESSION['login_employee_id']} and a.employee_id IN(SELECT employee_id from kpi_mster) and a.department_id IN ({$_SESSION['login_hod_dept']})")->num_rows; ?>
                    /
                    <?php $d = $conn->query("SELECT count(employee_id) as s FROM `employee_list` where doe='0000-00-00' and employee_id!={$_SESSION['login_employee_id']} and department_id IN ({$_SESSION['login_hod_dept']})"); $dd = $d->fetch_array(); echo $dd['s'] ?>
                </h3>
                <p>MP's / Employees &nbsp;</p>
            </div>
            <div class="icon">
                <i class="fa fa-user" style="color:#f37979;font-size:20px;top:66px"></i>
            </div>
        </div>
</a>
</div>

</div>
<style>
@media (max-width: 768px) {
    .carousel-inner .carousel-item>div {
        display: none;
    }

    .carousel-inner .carousel-item>div:first-child {
        display: block;
    }
}

.carousel-inner .carousel-item.active,
.carousel-inner .carousel-item-next,
.carousel-inner .carousel-item-prev {
    display: flex;
}

/* display 3 */
@media (min-width: 768px) {

    .carousel-inner .carousel-item-right.active,
    .carousel-inner .carousel-item-next {
        transform: translateX(33.333%);
    }

    .carousel-inner .carousel-item-left.active,
    .carousel-inner .carousel-item-prev {
        transform: translateX(-33.333%);
    }
}

.carousel-inner .carousel-item-right,
.carousel-inner .carousel-item-left {
    transform: translateX(0);
}
</style>


<!--/.Carousel Wrapper-->

<!--/.Carousel Wrapper-->


<!-- <div class="col-12">
          <div class="card">
            <div class="card-body">
              Welcome <?php echo $_SESSION['login_name'] ?>!
            </div>
          </div>
      </div> -->

<?php endif; ?>

<script>
$('#recipeCarousel').carousel({
    interval: 10000
})

$('.carousel .carousel-item').each(function() {
    var minPerSlide = 3;
    var next = $(this).next();
    if (!next.length) {
        next = $(this).siblings(':first');
    }
    next.children(':first-child').clone().appendTo($(this));

    for (var i = 0; i < minPerSlide; i++) {
        next = next.next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }

        next.children(':first-child').clone().appendTo($(this));
    }
});
</script>
<script>
$(document).ready(function() {
    //$('#ev').dataTable()

    //$('#ap').dataTable()
    $('.summernote').summernote({
        height: 150,
        toolbar: [
            ['style', ['style']],
            ['font', ['bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript',
                'clear'
            ]],
            ['fontname', ['fontname']],
            ['fontsize', ['fontsize']],
            ['color', ['color']],
            ['para', ['ol', 'ul', 'paragraph', 'height']],
            ['table', ['table']],
            ['insert', ['link', 'picture', 'video']],
            ['view', ['undo', 'redo', 'fullscreen', 'codeview', 'help']]

        ]
    })

    $('#manage_ticket').submit(function(e) {
        e.preventDefault()
        $('input').removeClass("border-danger")
        start_load()
        $('#msg').html('')
        $.ajax({
            url: 'ajax.php?action=save_ticket',
            data: new FormData($(this)[0]),
            cache: false,
            contentType: false,
            processData: false,
            method: 'POST',
            type: 'POST',
            success: function(resp) {
                //alert(resp);
                if (resp == 1) {
                    alert_toast('Data successfully saved.', "success");
                    setTimeout(function() {
                        location.replace('index.php?page=view_ticket')
                    }, 750)
                } else if (resp == 2) {
                    $('#msg').html(
                        "<div class='alert alert-danger'>Employee ID already exist.</div>"
                    );
                    $('[name="employee_id"]').addClass("border-danger")
                    end_load()
                }
            }
        })
    })
})
</script>

<?php
if(isset($_POST['save']))
{
  $t = $_POST['ticket_no'];
  $ass = $_POST['assign'];
  foreach($t as $k)
  {
  $conn1->query("UPDATE tickets set status=1,assigned_to=$ass,assigned_date=CURRENT_TIMESTAMP where id=$k");
 
  }
  ?><script>
alert_toast('Data successfully saved.', "success");
setTimeout(function() {
    location.replace('index.php?page=view_ticket')
}, 750)
</script><?php 
}
?>