<?php include'db_connect.php' ?>
<div class="col-lg-12">
	<div class="card card-outline card-success">
		
		<div class="card-body">
			<table class="table tabe-hover table-bordered" id="list">
				<thead>
					<tr>
                        <th><input type="checkbox" class="check-all-users"></th>

						<th class="text-center">#</th>
						<th>Ticket No</th>
						<th>Request By</th>
						<th>Dapartment</th>
                        <th>Category</th>
                        <th>Sub-Category</th>
                        <!-- <th>Problem Description</th> -->
                        <th>Status</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$i = 1;
					if($_SESSION['login_type'] == 2): 
					$qry = $conn1->query("SELECT * FROM tickets order by id desc");
					elseif($_SESSION['login_type'] == 1): 
					$qry = $conn1->query("SELECT * FROM tickets where assigned_to='".$_SESSION['login_employee_id']."' or req_by='".$_SESSION['login_employee_id']."' order by id desc");
					elseif($_SESSION['login_type'] == 0): 
					$qry = $conn1->query("SELECT * FROM tickets where req_by='".$_SESSION['login_employee_id']."' order by id desc");
					endif; 
					while($row= $qry->fetch_assoc()):
					?>
					<tr <?php if($row['status'] == 0) { ?>style="background:#f3c1c1!important"<?php } elseif($row['status'] == 1) { ?>style="background:#f1d092!important"<?php } elseif($row['status'] == 2) { ?>style="background:!important"<?php } ?>>
					<td><input type="checkbox" class="check-user"></td>	
                    <th class="text-center"><?php echo $i++ ?></th>
						<td><a href="index.php?page=ticket_details&&id=<?php echo $row['id']; ?>"><?php echo "PROTKT".$row['id'] ?></a></td>
						<td><?php $e = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM employee_list where employee_id={$row['req_by']}"); 
              $row1=$e->fetch_assoc();
               echo $row1['name'].'('.$row['req_by'].')'; ?></td>
						 <td><!--<a href="index.php?page=ticket_details&&id=<?php echo $row['id']; ?>">--><?php $dept = $conn->query("SELECT * FROM department_list where id='".$row['department']."' ");
							$deptdata=$dept->fetch_assoc();
							echo $deptdata['department'] ?></a></td>
                        <td><b><?php $sub = $conn1->query("SELECT * from category_list where id='".$row['category']."' ");
						while($catrow=$sub->fetch_assoc()) {
							echo $catrow['category']; } ?></b></td>
                        <td><?php $sub = $conn1->query("SELECT * from sub_category where id='".$row['sub_category']."' ");
						while($scat_row=$sub->fetch_assoc()) {
							echo $scat_row['sub_category']; } ?></td>
                        <!-- <td><?php echo $row['description'] ?></td> -->
                        <!-- <td><b style="color:white; padding:5px; <?php if($row['status'] == 0) { ?>background:#f15c53!important<?php } elseif($row['status'] == 1) { ?>background:orange!important<?php } elseif($row['status'] == 2) { ?>background:green!important<?php }?>"><?php if($row['status'] == 0) { echo "Not Assigned"; } else if($row['status'] == 1) { echo "Assigned"; } else if($row['status'] == 2) { echo "Resolved"; } ?></b></td> -->
						<td>
                <b
                    style="color:white; padding:5px; <?php if($row['status'] == 0) { ?>background:#f15c53!important<?php } elseif($row['status'] == 1) { ?>background:orange!important<?php } elseif($row['status'] == 2) { ?>background:green!important<?php }?>">
                    <?php 
                              if($row['status'] == 0) 
                              { ?>
							  <?php if($_SESSION['login_type'] == 1) { ?>
                    <b><button class="btn btn-info" id="sel" data-id="<?php echo $row['id'] ?>"><a href="#"
                                style="color:white;">Assign ticket to me</a></button> </b>
                    <?php 
							  } else { 
								echo "Ticket Not Assigned"; 
							  }
                              } else if($row['status'] == 1) 
                              {  
                                $e = $conn->query("SELECT employee_id,concat(firstname,' ',lastname) as name FROM employee_list where employee_id={$row['assigned_to']}"); 
                                $row4=$e->fetch_assoc();
                                echo "Assigned To ".$row4['name']; 
                              } else if($row['status'] == 2) 
                              { 
                                echo "Resolved"; 
                              } 
                              ?>
                </b>
            </td>
						
					</tr>	
				<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<script>
$('#sel').click(function() {
    _conf("Are you sure to assign this ticket?", "self_assign", [$(this).attr('data-id')])
})

function self_assign($id) {
    start_load()
    $.ajax({
        url: 'ajax.php?action=self_assign',
        method: 'POST',
        data: {
            id: $id
        },
        success: function(resp) {
            if (resp == 1) {
                alert_toast("Ticket Assigned Successfully", 'success')
                setTimeout(function() {
                    location.reload()
                }, 1500)

            }
        }
    })
}


	$(document).ready(function(){
		$('#list').DataTable({
		dom: 'Blftip',
        buttons: [
            'copyHtml5',
            'excelHtml5',
            'csvHtml5',
            'pdfHtml5'
        ],
        lengthMenu: [
            [10, 25, 50, -1],
            [10, 25, 50, 'All'],
        ]
    });
	})
	$('.view_user').click(function(){
		uni_modal("<i class='fa fa-id-card'></i> User Details","view_user.php?id="+$(this).attr('data-id'))
	})
	$('.delete_user').click(function(){
	_conf("Are you sure to delete this user?","delete_user",[$(this).attr('data-id')])
	})
	function delete_user($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_user',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>