<?php
?>
<link rel="stylesheet" href="assets/dist/css/filter_multi_select.css" />
<script src="assets/dist/js/filter-multi-select-bundle.min.js"></script>
<div class="col-lg-12">
	<div class="card">
		<div class="card-body">
			<div id="msg"></div>
			<form action="" id="manage_ticket">
				<input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
 				<div class="row">
					<div class="col-md-6 border-right">
						<!-- <div class="form-group">
							<label for="" class="control-label">Ticket Title <span style="color:red">*</span></label>
							<input type="text" name="title" class="form-control form-control-sm" required value="<?php echo isset($employee_id) ? $employee_id : '' ?>">
						</div> -->
						<div class="form-group">
							<label for="" class="control-label">Department <span style="color:red">*</span></label>
							<select name="department" id="department" class="form-control form-control-sm select2">
								<option value="">Select Department Here</option>
							<?php
								$dept = $conn->query("SELECT * FROM department_list"); 
							while($deptdata=$dept->fetch_assoc()):
							?>
							<option value="<?php echo $deptdata['id'] ?>" <?php echo isset($department_id) && $department_id == $row['id'] ? 'selected' : '' ?>><?php echo $deptdata['department'] ?></option>
							<?php endwhile; ?>
							</select>
						</div>
						<div class="form-group">
							<label for="" class="control-label">Category<span style="color:red">*</span></label>
							
							<select name="category" id="category" class="form-control form-control-sm select2">
								<option value="">Select Category Here</option>
							<?php
								$cat = $conn1->query("SELECT * FROM category_list"); 
							while($row=$cat->fetch_assoc()):
							?>
							<option value="<?php echo $row['id'] ?>" <?php echo isset($department_id) && $department_id == $row['id'] ? 'selected' : '' ?>><?php echo $row['category'] ?></option>
							<?php endwhile; ?>
			</select>
						</div>
						<div id="response">
						<div class="form-group">
							<label for="" class="control-label">Sub-Category<span style="color:red">*</span></label>
							<select name="sub_category" id="sub_category" class="form-control form-control-sm select2">
								<option value="">Select Sub-Category Here</option>
							<?php
								$scat = $conn1->query("SELECT * FROM sub_category"); 
							while($row=$scat->fetch_assoc()):
							?>
							<option value="<?php echo $row['sub_category'] ?>" <?php echo isset($department_id) && $department_id == $row['id'] ? 'selected' : '' ?>><?php echo $row['sub-category'] ?></option>
							<?php endwhile; ?>
			</select>
						</div></div>
						<div class="form-group">
							<label for="" class="control-label">Uploads</label>
							<div class="custom-file">
		                      <input type="file" class="custom-file-input" id="customFile" name="uploads" onchange="displayImg(this,$(this))" multiple>
		                      <label class="custom-file-label" for="customFile">Choose file</label>
		                    </div>
						</div>
						
						
					</div>
					<div class="col-md-6">
					<div class="form-group">
							<label for="" class="control-label">Problem Description <span style="color:red">*</span></label>							
                        <textarea name="description" id="description" cols="10" rows="1" class="form-control rounded-0 summernote" data-placeholder="Write the Roles & Responsibilities here." data-height="40vh" required><?php echo isset($content) ? $content : '' ?></textarea>
						</div>
						
						
						<div class="form-group">
						
						<div>
					</div>
				</div>
				<hr>
				<div class="col-lg-12 text-right justify-content-center d-flex">
					<button class="btn btn-primary mr-2">Save</button>
					<button class="btn btn-secondary" type="button" onclick="location.href = 'index.php?page=home&&st=0'">Cancel</button>
				</div>
			</form>
		</div>
	</div>
</div>
<style>
	img#cimg{
		height: 15vh;
		width: 15vh;
		object-fit: cover;
		border-radius: 100% 100%;
	}
</style>
<script>
	$(document).ready(function(){
		$('.summernote').summernote({
        height: 150,
        toolbar: [
            [ 'style', [ 'style' ] ],
            [ 'font', [ 'bold', 'italic', 'underline', 'strikethrough', 'superscript', 'subscript', 'clear'] ],
            [ 'fontname', [ 'fontname' ] ],
            [ 'fontsize', [ 'fontsize' ] ],
            [ 'color', [ 'color' ] ],
            [ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            [ 'table', [ 'table' ] ],
			['insert', ['link', 'picture', 'video']],
            [ 'view', [ 'undo', 'redo', 'fullscreen', 'codeview', 'help' ] ]
			
        ]
    })
     })
	
	$('[name="password"],[name="cpass"]').keyup(function(){
		var pass = $('[name="password"]').val()
		var cpass = $('[name="cpass"]').val()
		if(cpass == '' ||pass == ''){
			$('#pass_match').attr('data-status','')
		}else{
			if(cpass == pass){
				$('#pass_match').attr('data-status','1').html('<i class="text-success">Password Matched.</i>')
			}else{
				$('#pass_match').attr('data-status','2').html('<i class="text-danger">Password does not match.</i>')
			}
		}
	})
	function displayImg(input,_this) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
	        	$('#cimg').attr('src', e.target.result);
	        }

	        reader.readAsDataURL(input.files[0]);
	    }
	}
	$('#manage_ticket').submit(function(e){
		e.preventDefault()
		$('input').removeClass("border-danger")
		start_load()
		$('#msg').html('')		
		$.ajax({
			url:'ajax.php?action=save_ticket',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
			//alert(resp);
				if(resp == 1){
					alert_toast('Data successfully saved.',"success");
					setTimeout(function(){
						location.replace('index.php?page=view_ticket')
					},750)
				}else if(resp == 2){
					$('#msg').html("<div class='alert alert-danger'>Employee ID already exist.</div>");
					$('[name="employee_id"]').addClass("border-danger")
					end_load()
				}
			}
		})
	})
	$("select#category").change(function(){
        var cat = $("#category option:selected").val();
		//alert(dept);
        $.ajax({
            type: 'POST',
            url: 'ajax.php?action=get_subcat',
            data: { cat : cat } 
        }).done(function(data){
			// alert(data);
            $("#response").html(data);
			$('#sub_category').select2({
			placeholder:'Please select Employee',
			width:'100%'
			})
        });
    });
</script>