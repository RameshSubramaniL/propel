<?php 
include('db_connect.php');
session_start();
if(isset($_GET['id'])){
$type = array("employee_list","employee_list","users","employee_list");
$user = $conn->query("SELECT * FROM {$type[$_SESSION['login_type']]} where id =".$_GET['id']);
foreach($user->fetch_array() as $k =>$v){
	$meta[$k] = $v;
}
}
?>
<div class="container-fluid">
	<div id="msg"></div>
	
	<form action="" id="manage-user">	
		<input type="hidden" name="id" value="<?php echo isset($meta['id']) ? $meta['id']: '' ?>">
		<div class="form-group">
			<label for="name">Select Employee</label>
			<!-- <input type="text" name="name" id="name" class="form-control" value="<?php echo isset($meta['firstname']) ? $meta['firstname']: '' ?>" required> -->
			<select name="employee_id" id="employee_id" class="form-control form-control-sm select2" required="">
			<option value="">Select Employee Here</option>
							<?php 
							echo "SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where doe='0000-00-00' order by concat(firstname,' ',lastname) asc";
							$employees = $conn->query("SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where doe='0000-00-00' order by concat(firstname,' ',lastname) desc");
							while($row=$employees->fetch_assoc()):
							?>
							<option value="<?php echo $row['employee_id'] ?>" selected><?php echo $row['name'].' - '.$row['employee_id'] ?></option>
							<?php endwhile; ?>
			</select>
		</div>
		
		<div class="form-group">
			<label for="name">Role</label>
            <select name="role" id="role" class="form-control form-control-sm select2">
								<option value="">Select Category Here</option>
							    <option value="2">Admin</option>
                                <option value="1">Staff</option>
			</select>			</div>

	</form>
</div>
<style>
	img#cimg{
		height: 15vh;
		width: 15vh;
		object-fit: cover;
		border-radius: 100% 100%;	
	}
</style>
<script>
	$('#employee_id').select2({
			placeholder:'Please select Employee',
			width:'100%'
			})
	function displayImg(input,_this) {
	    if (input.files && input.files[0]) {
	        var reader = new FileReader();
	        reader.onload = function (e) {
		        	$('#cimg').attr('src', e.target.result);
	        }

	        reader.readAsDataURL(input.files[0]);
	    }
	}
	$('#manage-user').submit(function(e){
		e.preventDefault();
		start_load()
		$.ajax({
			url:'ajax.php?action=save_team',
			data: new FormData($(this)[0]),
		    cache: false,
		    contentType: false,
		    processData: false,
		    method: 'POST',
		    type: 'POST',
			success:function(resp){
				//alert(resp);
				if(resp ==1){
					alert_toast("Data successfully saved",'success')
					setTimeout(function(){
						location.reload()
					},1500)
				}else{
					$('#msg').html('<div class="alert alert-danger">Username already exist</div>')
					end_load()
				}
			}
		})
	})

</script>