<?php
include 'db_connect.php';
if(isset($_GET['id'])){
	$qry = $conn->query("SELECT * FROM sub_category where id={$_GET['id']}")->fetch_array();
	foreach($qry as $k => $v){
		$$k = $v;
	}
}
?>
<div class="container-fluid">
	<form action="" id="manage-designation">
		<input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
		<div id="msg" class="form-group"></div>
		<div class="form-group">
			<label for="designation" class="control-label">Category</label>
			<select name="category" id="category" class="form-control form-control-sm select2">
								<option value="">Select Category Here</option>
							<?php
								$cat = $conn1->query("SELECT * FROM category_list"); 
							while($row=$cat->fetch_assoc()):
							?>
							<option value="<?php echo $row['id'] ?>" <?php echo isset($category) && $category == $row['id'] ? 'selected' : '' ?>><?php echo $row['category'] ?></option>
							<?php endwhile; ?>
			</select>		</div>
		<div class="form-group">
			<label for="description" class="control-label">Sub Category</label>
			<input type="text" class="form-control form-control-sm" name="sub_category" id="sub_category" value="<?php echo isset($designation) ? $designation : '' ?>">
		</div>
	</form>
</div>
<script>
	$(document).ready(function(){
		$('#manage-designation').submit(function(e){
			e.preventDefault();
			start_load()
			$('#msg').html('')
			$.ajax({
				url:'ajax.php?action=save_designation',
				method:'POST',
				data:$(this).serialize(),
				success:function(resp){
					if(resp == 1){
						alert_toast("Data successfully saved.","success");
						setTimeout(function(){
							location.reload()	
						},1750)
					}else if(resp == 2){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Sub-Category already exist.</div>')
						end_load()
					}else if(resp == 3){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Please Fill All Field.</div>')
						end_load()
					}
				}
			})
		})
	})
	$('#category').select2({
			placeholder:'Please select Category',
			width:'100%'
			})
</script>