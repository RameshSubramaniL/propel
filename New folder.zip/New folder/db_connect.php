<?php 

$conn= new mysqli('localhost','root','','epes')or die("Could not connect to mysql".mysqli_error($con));
$conn1= new mysqli('localhost','root','','hd')or die("Could not connect to mysql".mysqli_error($con));

