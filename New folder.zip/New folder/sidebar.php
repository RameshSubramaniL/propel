  <aside class="main-sidebar sidebar-light-primary elevation-4">
    <div class="dropdown">
   	<a href="index.php?page=home&&st=0" class="brand-link">
        <h3 class="text-center p-0 m-0"><b>HD</b></h3>
      
    </a>
      
    </div>
    <div class="sidebar pb-4 mb-4">
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column nav-flat" data-widget="treeview" role="menu" data-accordion="false">
         <li class="nav-item dropdown">
            <a href="index.php?page=home&&st=0" class="nav-link nav-home">
              <i class="nav-icon fas fa-clipboard"></i>
              <p>
                Tickets
              </p>
            </a>
          </li> 
          <?php if($_SESSION['login_type'] != 0): ?>

          <li class="nav-item dropdown">
            <a href="index.php?page=team" class="nav-link nav-team">
              <i class="nav-icon fas fa-user"></i>
              <p>
                Team
              </p>
            </a>
          </li> 
          <li class="nav-item dropdown">
            <a href="index.php?page=category" class="nav-link nav-category">
              <i class="nav-icon fas fa-list"></i>
              <p>
                Category
              </p>
            </a>
          </li> 
         <?php endif; ?>
        </ul>
      </nav>
    </div>
  </aside>
  <script>
  	$(document).ready(function(){
      
      var page = '<?php echo isset($_GET['page']) ? $_GET['page'] : 'home' ?>';
  		var s = '<?php echo isset($_GET['s']) ? $_GET['s'] : '' ?>';
      if(s!='')
        page = page+'_'+s;
  		if($('.nav-link.nav-'+page).length > 0){
             $('.nav-link.nav-'+page).addClass('active')
  			if($('.nav-link.nav-'+page).hasClass('tree-item') == true){
            $('.nav-link.nav-'+page).closest('.nav-treeview').siblings('a').addClass('active')
  				$('.nav-link.nav-'+page).closest('.nav-treeview').parent().addClass('menu-open')
  			}
        if($('.nav-link.nav-'+page).hasClass('nav-is-tree') == true){
          $('.nav-link.nav-'+page).parent().addClass('menu-open')
        }
  		}
     
  	})
  </script>