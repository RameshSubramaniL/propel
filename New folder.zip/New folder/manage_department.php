<?php
include 'db_connect.php';
if(isset($_GET['id'])){
	//echo "SELECT * FROM category_list where id={$_GET['id']}";
	$qry = $conn1->query("SELECT * FROM category_list where id={$_GET['id']}")->fetch_array();
	foreach($qry as $k => $v){
		$$k = $v;
	}
}
?>
<div class="container-fluid">
	<form action="" id="manage-department">
		<input type="hidden" name="id" value="<?php echo isset($id) ? $id : '' ?>">
		<div id="msg" class="form-group"></div>
		<div class="form-group">
			<label for="department" class="control-label">Category</label>
			<input type="text" class="form-control form-control-sm" name="category" id="category" required="required" value="<?php echo isset($category) ? $category : '' ?>">
		</div>		
	</form>
</div>
<script>
	$(document).ready(function(){
		
		$('#manage-department').submit(function(e){
			
			$("input").prop('required',true);
			e.preventDefault();
			start_load()
			$('#msg').html('')
			$.ajax({
				url:'ajax.php?action=save_department',
				method:'POST',
				data:$(this).serialize(),
				success:function(resp){
					//alert(resp);
					if(resp == 1){
						alert_toast("Data successfully saved.","success");
						setTimeout(function(){
							location.reload()	
						},1750)
					}else if(resp == 2){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Category already exist.</div>')
						end_load()
					}
					else if(resp == 3){
						$('#msg').html('<div class="alert alert-danger"><i class="fa fa-exclamation-triangle"></i> Please Fill Field.</div>')
						end_load()
					}
				}
			})
		})
	})

</script>