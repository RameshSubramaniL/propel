﻿<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/phpMailer/vendor/phpmailer/src/Exception.php';
require_once __DIR__ . '/phpMailer/vendor/phpmailer/src/PHPMailer.php';
require_once __DIR__ . '/phpMailer/vendor/phpmailer/src/SMTP.php';
session_start();
ini_set('display_errors', 1);
Class Action {
	private $db;

	public function __construct() {
		ob_start();
   	include 'db_connect.php';
    
    $this->db = $conn1;
	$this->db1 = $conn;
	}
	function __destruct() {
	    $this->db->close();
	    ob_end_flush();
	}

	function login(){
		extract($_POST);
		
		// $qrys = $this->db1->query("SELECT role from employee_list where employee_id = '".$employee_id."' and password = '".md5($password)."' and doe='0000-00-00'");
		// $rs = $qrys->fetch_array();
		$k = $this->db->query("SELECT role from team_list where employee_id='".$employee_id."'");
		$rs = $k->fetch_array();
		if($k->num_rows != 0)
		$login = $rs['role']; 
		else
		$login = 0;
		
		$type = array("employee_list","employee_list","employee_list","employee_list");
		if($login != 3)		
		$qry = $this->db1->query("SELECT *,concat(firstname,' ',lastname) as name FROM {$type[$login]} where employee_id = '".$employee_id."' and password = '".md5($password)."'  ");
		else
		$qry = $this->db1->query("SELECT *,concat(firstname,' ',lastname) as name FROM {$type[$login]} where employee_id = '".$employee_id."' and password = '".md5($password)."' and is_hod=1");

		if($qry->num_rows > 0){
			foreach ($qry->fetch_array() as $key => $value) {
				if($key != 'password' && !is_numeric($key))
					$_SESSION['login_'.$key] = $value;
			}
					$_SESSION['login_type'] = $login;
				return 1;
		}else{
			return 2;
		}
	}
	function logout(){
		session_destroy();
		foreach ($_SESSION as $key => $value) {
			unset($_SESSION[$key]);
		}
		header("location:login.php");
	}
	function login2(){
		extract($_POST);
			$qry = $this->db->query("SELECT *,concat(lastname,', ',firstname,' ',middlename) as name FROM students where student_code = '".$student_code."' ");
		if($qry->num_rows > 0){
			foreach ($qry->fetch_array() as $key => $value) {
				if($key != 'password' && !is_numeric($key))
					$_SESSION['rs_'.$key] = $value;
			}
				return 1;
		}else{
			return 3;
		}
	}
	function save_user(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass','password')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		if(!empty($password)){
					$data .= ", password=md5('$password') ";

		}
		$check = $this->db->query("SELECT * FROM users where email ='$email' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		if($check > 0){
			return 2;
			exit;
		}
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}
		if(empty($id)){
		if(!isset($_FILES['img']) || (isset($_FILES['img']) && $_FILES['img']['tmp_name'] == '')){	
			$data .= ", avatar = 'no-image-available.png' ";
		}
			$save = $this->db->query("INSERT INTO users set $data");
		}else{
			$save = $this->db->query("UPDATE users set $data where id = $id");
		}

		if($save){
			return 1;
		}
	}
	function signup(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass')) && !is_numeric($k)){
				if($k =='password'){
					if(empty($v))
						continue;
					$v = md5($v);

				}
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}

		$check = $this->db->query("SELECT * FROM users where email ='$email' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		if($check > 0){
			return 2;
			exit;
		}
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}
		if(empty($id)){
			if(!isset($_FILES['img']) || (isset($_FILES['img']) && $_FILES['img']['tmp_name'] == '')){	
			$data .= ", avatar = 'no-image-available.png' ";
		}
			$save = $this->db->query("INSERT INTO users set $data");

		}else{
			$save = $this->db->query("UPDATE users set $data where id = $id");
		}

		if($save){
			if(empty($id))
				$id = $this->db->insert_id;
			foreach ($_POST as $key => $value) {
				if(!in_array($key, array('id','cpass','password')) && !is_numeric($key))
					$_SESSION['login_'.$key] = $value;
			}
					$_SESSION['login_id'] = $id;
				if(isset($_FILES['img']) && !empty($_FILES['img']['tmp_name']))
					$_SESSION['login_avatar'] = $fname;
			return 1;
		}
	}

	function update_user(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass','table','password')) && !is_numeric($k)){
				
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$type = array("employee_list","users","employee_list","employee_list");
		// $check = $this->db->query("SELECT * FROM {$type[$_SESSION['login_type']]} where email ='$email' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		// if($check > 0){
		// 	return 2;
		// 	exit;
		// }
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}
		if(!empty($password))
			$data .= " ,password=md5('$password') ";
		if(empty($id)){
			if(!isset($_FILES['img']) || (isset($_FILES['img']) && $_FILES['img']['tmp_name'] == '')){	
				$data .= ", avatar = 'no-image-available.png' ";
			}
			$save = $this->db->query("INSERT INTO {$type[$_SESSION['login_type']]} set $data");
		}else{
			$eid = $_SESSION['login_id'];
			
			$employees = $this->db->query("SELECT * FROM employee_list where id = $eid");
			$row=$employees->fetch_assoc();
			$emp = $row['employee_id'];
						
			
			$save = $this->db->query("UPDATE employee_list set $data where employee_id = $emp");
			//return 1;
		}

		if($save){
			foreach ($_POST as $key => $value) {
				if($key != 'password' && !is_numeric($key))
					$_SESSION['login_'.$key] = $value;
			}
			if(isset($_FILES['img']) && !empty($_FILES['img']['tmp_name']))
					$_SESSION['login_avatar'] = $fname;
			return 1;
		}
	}
	function delete_user(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM users where id = ".$id);
		if($delete)
			return 1;
	}
	function save_system_settings(){
		extract($_POST);
		$data = '';
		foreach($_POST as $k => $v){
			if(!is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		if($_FILES['cover']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['cover']['name'];
			$move = move_uploaded_file($_FILES['cover']['tmp_name'],'../assets/uploads/'. $fname);
			$data .= ", cover_img = '$fname' ";

		}
		$chk = $this->db->query("SELECT * FROM system_settings");
		if($chk->num_rows > 0){
			$save = $this->db->query("UPDATE system_settings set $data where id =".$chk->fetch_array()['id']);
		}else{
			$save = $this->db->query("INSERT INTO system_settings set $data");
		}
		if($save){
			foreach($_POST as $k => $v){
				if(!is_numeric($k)){
					$_SESSION['system'][$k] = $v;
				}
			}
			if($_FILES['cover']['tmp_name'] != ''){
				$_SESSION['system']['cover_img'] = $fname;
			}
			return 1;
		}
	}
	function save_image(){
		extract($_FILES['file']);
		if(!empty($tmp_name)){
			$fname = strtotime(date("Y-m-d H:i"))."_".(str_replace(" ","-",$name));
			$move = move_uploaded_file($tmp_name,'assets/uploads/'. $fname);
			$protocol = strtolower(substr($_SERVER["SERVER_PROTOCOL"],0,5))=='https'?'https':'http';
			$hostName = $_SERVER['HTTP_HOST'];
			$path =explode('/',$_SERVER['PHP_SELF']);
			$currentPath = '/'.$path[1]; 
			if($move){
				return $protocol.'://'.$hostName.$currentPath.'/assets/uploads/'.$fname;
			}
		}
	}
	function save_department(){	
		extract($_POST);
		if(($_POST['category'] == ""))
		{
			return 3;
		}
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','user_ids')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$chk = $this->db->query("SELECT * FROM category_list where category = '$category'")->num_rows;
		if($chk > 0){
			return 2;
		}
		if(isset($user_ids)){
			$data .= ", user_ids='".implode(',',$user_ids)."' ";
		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO category_list set $data");
		}else{
			$save = $this->db->query("UPDATE category_list set $data where id = $id");
		}
		if($save){
			return 1;
		}
	}
	function delete_department(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM department_list where id = $id");
		if($delete){
			return 1;
		}
	}
	function save_designation(){
		extract($_POST);
		if(($_POST['category'] == "") || ($_POST['sub_category'] == ""))
		{
			return 3;
		}
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','user_ids')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$chk = $this->db->query("SELECT * FROM sub_category where category = '$category' and sub_category='$sub_category' ")->num_rows;
		if($chk > 0){
			return 2;
		}
		if(isset($user_ids)){
			$data .= ", user_ids='".implode(',',$user_ids)."' ";
		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO sub_category set $data");
		}else{
			$save = $this->db->query("UPDATE sub_category set $data where id = $id");
		}
		if($save){
			return 1;
		}
	}

	function delete_designation(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM designation_list where id = $id");
		if($delete){
			return 1;
		}
	}

	function save_employee(){
		extract($_POST);
		$data = "";
$_POST['role'] = 0;
$employeeid=$_POST['employee_id'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$mobile=$_POST['mobile'];
$doj=$_POST['doj'];
$doe=$_POST['doe'];
$password=$_POST['password'];
$department_id=$_POST['department_id'];
if(isset($_POST['old_id'])) { 
	$old_id = $_POST['old_id']; 
	if($old_id != $employee_id)
		{
			$this->db->query("UPDATE kpi_mster set employee_id=$employee_id where employee_id = $old_id");
			$this->db->query("UPDATE ratings set employee_id=$employee_id where employee_id = $old_id");
			$this->db->query("UPDATE task_list set employee_id=$employee_id where employee_id = $old_id");

		}
}
unset($_POST['old_id']);
$chk = $this->db->query("SELECT * FROM department_list where id=$department_id");
$s = $chk->fetch_array();
$middlename=$s['description'];
$designation_id=$_POST['designation_id'];
$evaluator_id=$_POST['department_id'];
if(!isset($is_hod) && !isset($role)) { $_POST['hod_dept'] = "0,0";}
if(isset($is_hod)) { $is_hod = $_POST['is_hod']; } 
if(isset($role)) { $role = $_POST['role']; } 
if(!isset($_POST['is_hod']))
$_POST['is_hod'] =0;
if(isset($_POST['hod_dept']) && (isset($is_hod) || isset($role))) { $hod_dept1 = $_POST['hod_dept']; 
$hod_depts = "";
foreach($hod_dept1 as $dt)
{        
           $hod_depts .= ','.$dt;
}
$hod_dept = ltrim($hod_depts, ','); } 
if(isset($is_hod) == '1') {
$_POST['hod_dept'] = $hod_dept; $_POST['role'] = 3;}
else if(isset($role) == 1) { $_POST['hod_dept'] = $hod_dept; $_POST['role'] = 1; $_POST['is_hod'] = 2; }
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass','password')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		if(!empty($password)){
					$data .= ", password=md5('$password') ";

		}
		$check = $this->db->query("SELECT * FROM employee_list where employee_id ='$employeeid' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		
		if($check > 0){
			return 2;
			exit;
		}
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}


		if(empty($id)){
			if(!isset($_FILES['img']) || (isset($_FILES['img']) && $_FILES['img']['tmp_name'] == '')){	
				$data .= ", avatar = 'no-image-available.png' ";
			}
			
			$save = $this->db->query("INSERT INTO employee_list set $data");
			//$save = $this->db->query("Insert into employee_list (`employee_id`, `firstname`, `middlename`, `lastname`, `email`, `password`, `department_id`, `designation_id`, `evaluator_id`, `avatar`, `date_created`) VALUES ($employee_id, '$firstname', '$lastname', '$email', '$password', $department_id, '$designation_id, '$evaluator_id', '$email', CURRENT_TIMESTAMP)");
		}else{			
			//echo "UPDATE employee_list set $data where id = $id";
			
			$save = $this->db->query("UPDATE employee_list set $data where id = $id");
		}
//echo "$save";
			$data .= ", middlename='$middlename' ";
			if($_POST['is_hod'] != 0 )
			{
				$check = $this->db->query("SELECT * FROM evaluator_list where employee_id =$employeeid")->num_rows;
				$n = $firstname.' '.$lastname;
				$p=md5($password);
				//echo "INSERT INTO evaluator_list(employee_id,firstname,password) values (,'$n','$p')";
				if($check == 0)
				{
				$save = $this->db->query("INSERT INTO evaluator_list(employee_id,firstname,password) values ('$employeeid','$n','$p')");
				}
			}
		if($save<>0){
			return 1;
		}
	}
	function delete_employee(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM employee_list where id = ".$id);
		if($delete<>0)
			return 1;
	}
	function save_evaluator(){
		extract($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','cpass','password')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		if(!empty($password)){
					$data .= ", password=md5('$password') ";

		}
		$check = $this->db->query("SELECT * FROM evaluator_list where email ='$email' ".(!empty($id) ? " and id != {$id} " : ''))->num_rows;
		if($check > 0){
			return 2;
			exit;
		}
		if(isset($_FILES['img']) && $_FILES['img']['tmp_name'] != ''){
			$fname = strtotime(date('y-m-d H:i')).'_'.$_FILES['img']['name'];
			$move = move_uploaded_file($_FILES['img']['tmp_name'],'assets/uploads/'. $fname);
			$data .= ", avatar = '$fname' ";

		}
	

		if(empty($id)){
			if(!isset($_FILES['img']) || (isset($_FILES['img']) && $_FILES['img']['tmp_name'] == '')){	
				$data .= ", avatar = 'no-image-available.png' ";
			}
			$save = $this->db->query("INSERT INTO evaluator_list set $data");
		}else{
			$save = $this->db->query("UPDATE evaluator_list set $data where id = $id");
		}

		if($save<>0){
			return 1;
		}
//echo $save;
	}
	function delete_evaluator(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM evaluator_list where id = ".$id);
		if($delete)
			return 1;
	}
	function save_task(){
		extract($_POST);
		$emp = $_POST['employee_id'];
		$data_task=$_POST['task'];
		$due_date=$_POST['due_date'];
		$from=$_POST['from'];
		$to=$_POST['to'];
		$mode=$_POST['mode'];
		$period=$_POST['period'];
		$save = 0;
		// $description=$_POST['description'];
		if(empty($emp))
		{
			if($period == "q1") { $ps = "first"; $f="April"; $t="June"; } elseif($period == "q2") { $ps = "second"; $f="July"; $t="Sep"; } elseif($period == "q3") { $ps = "Third"; $f="Oct"; $t="Dec"; } elseif($period == "q4") { $ps = "Fourth";$f="Jan"; $t="March"; }
			$q2 = $this->db->query("select employee_id from employee_list where doe='0000-00-00'");
			while($s1 = $q2->fetch_array())
			{
			$p = $s1['employee_id'];
			$q1 = $this->db->query("SELECT * FROM task_list WHERE employee_id=$p AND year_from=$from AND year_to=$to AND mode='$mode' AND pperiod='$period'");
			$count = mysqli_num_rows($q1);
			$data = "";
			$data .= " task='$data_task' ";
			$data .= ", year_from='$from' ";
			$data .= ", year_to='$to' ";
			$data .= ", mode='$mode' ";
			$data .= ", pperiod='$period' ";
			$data .= ", employee_id='$p' ";
			$data .= ", due_date='$due_date' ";
			$data .= ", status=0 ";
			$data .= ", status1=0 ";

			if($count <= 0){				
				$qry8 = $this->db->query("SELECT * FROM employee_list WHERE employee_id=$p");
				$row8 = $qry8->fetch_array();
				$save = $this->db->query("INSERT INTO task_list set $data"); 					
			}
			}
			$q222 = $this->db->query("select employee_id,email from employee_list where doe='0000-00-00' and email!=''");

			$mail = new PHPMailer(true);    // Server settings
			//$mail->SMTPDebug = SMTP::DEBUG_SERVER; // for detailed debug output
			$mail->isSMTP();
			$mail->Host = 'zimbra.propelind.com';
			$mail->SMTPAuth = true;
			$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
			$mail->Port = 587;
			$mail->Username = 'larancy@propelind.com'; // YOUR gmail email
			$mail->Password = '@LOpel@123'; // YOUR gmail password
			// Sender and recipient settings
			$mail->setFrom('barani@propelind.com', 'Baranikumar - HR');
			while($sw = $q222->fetch_array())
                {
                  $mail->addAddress($sw['email'], $sw['email']);
                    //$mail->addAddress($rowy['email'], $rowy['email']);
                }   
			$mail->addCC('barani@propelind.com', 'Baranikumar - HR');
			//$mail->addCC('raju@propelind.com', 'Raju - HR');
			$mail->addReplyTo('barani@propelind.com', 'Baranikumar - HR'); // to set the reply to
			// Setting the email content
			$mail->IsHTML(true);
			$mail->Subject = "Employee Appraisal For ".ucfirst($ps)." Quarter ".ucfirst($f)." ".$from." to ".ucfirst($t)." ".$from;
			$mail->Body = '
			<body style="background-color:grey">
			<table align="center" border="0" cellpadding="0" cellspacing="0" width="550" bgcolor="white" style="border:2px solid black">
				<tbody>
					<tr>
						<td align="center">
							<table align="center" border="0" cellpadding="0" cellspacing="0" class="col-550" width="550">
								<tbody>
									<tr>
										<td align="center" style="background-color: #4cb96b;
												   height: 50px;">
		
											<a href="#" style="text-decoration: none;">
												<p style="color:white;
														  font-weight:bold;">
														  EMPLOYEE APPRAISAL FOR '.strtoupper($f).'('.$from.')-'.strtoupper($t).'('.$from.')
												</p>
											</a>
										</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
					
		
					<tr style="display: inline-block;">
						<td style="height: 150px;
								   padding: 20px;
								   border: none; 
								   border-bottom: 2px solid #361B0E;
								   background-color: white;">
		
							<h5 style="text-align: left;
									   align-items: center;">
									   Dear All,<br><br>

									   Please find the below Performance Appraisal Link for the '.$ps.' quarter ('.$f.' '.$from.' to '.$t.' '.$from.')<br><br>
									   
									   Kindly update all the data in your MP and complete the appraisal process on or before '.date('d-m-Y',strtotime($due_date)).'.<br><br>
									   
									   Internal users:<br><br>
									   
									   http://192.168.1.236/epes/login.php<br><br><br>
									   
									   User Name: Your employee Code (Eg:123)<br><br>
									   Password: 123456 (Note : Those who changed the password earlier can use the same password.)<br><br><br>
									   
									   Once you login kindly change the password immediately.<br><br>
									   Click at the top right corner and click manage account & change the password.<br><br>
									   
									   External Users:<br><br>
									   
									   https://epes.propelind.com:6072/login.php<br><br><br>
									   
									   User Name: Your employee Code (Eg:123)<br><br>
									   Password: 123456 (Note : Those who changed the password earlier can use the same password.)<br><br><br>
									   
									   Kindly circulate the mail for your teammates if anyone is missing.
							</h5>
							<!-- <p class="data" style="text-align: justify-all;
									  align-items: center; 
									  font-size: 15px;
									  padding-bottom: 12px;">
								Design Patterns….??? I think you have heard this name before in programming… Yes, you might have heard this name before in programming if you are…
							</p> -->
							<!-- <p>
								<a href="https://www.geeksforgeeks.org/design-patterns-a-must-skill-to-have-for-software-developers-in-2019/" style="text-decoration: none; 
										  color:black; 
										  border: 2px solid #4cb96b; 
										  padding: 10px 30px;
										  font-weight: bold;"> 
								   Read More 
							  </a>
							</p> -->
						</td>
					</tr>
				</tbody>
			</table>
		</body>
							';
			$mail->AltBody = 'This is a plain-text message body.';
			$mail->send();
			
		}
		else
		{
		foreach($emp as $p)
		{
			if($period == "q1") { $ps = "first"; $f="April"; $t="June"; } elseif($period == "q2") { $ps = "second"; $f="July"; $t="Sep"; } elseif($period == "q3") { $ps = "Third"; $f="Oct"; $t="Dec";} elseif($period == "q4") { $ps = "Fourth"; $f="Jan"; $t="March"; }
			$q1 = $this->db->query("SELECT * FROM task_list WHERE employee_id=$p AND year_from=$from AND year_to=$to AND mode='$mode' AND pperiod='$period'");
			$count = mysqli_num_rows($q1);
			$data = "";
			$data .= " task='$data_task' ";
			$data .= ", year_from='$from' ";
			$data .= ", year_to='$to' ";
			$data .= ", mode='$mode' ";
			$data .= ", pperiod='$period' ";
			$data .= ", employee_id='$p' ";
			$data .= ", due_date='$due_date' ";
			$data .= ", status=0 ";
			$data .= ", status1=0 ";
			if($count <= 0){
				$qry8 = $this->db->query("SELECT * FROM employee_list WHERE employee_id=$p");
				$row8 = $qry8->fetch_array();
				$save = $this->db->query("INSERT INTO task_list set $data");
				if($row8['email'] != "")
				{
				$mail = new PHPMailer(true);    // Server settings
				//$mail->SMTPDebug = SMTP::DEBUG_SERVER; // for detailed debug output
				$mail->isSMTP();
				$mail->Host = 'zimbra.propelind.com';
				$mail->SMTPAuth = true;
				$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
				$mail->Port = 587;
				$mail->Username = 'larancy@propelind.com'; // YOUR gmail email
				$mail->Password = '@LOpel@123'; // YOUR gmail password
				// Sender and recipient settings
				$mail->setFrom('barani@propelind.com', 'Baranikumar - HR');
				$mail->addAddress($row8['email'], $row8['email']);
				$mail->addCC('barani@propelind.com', 'Baranikumar - HR');
				//$mail->addCC('raju@propelind.com', 'Raju - HR');
				$mail->addReplyTo('barani@propelind.com', 'Baranikumar - HR'); // to set the reply to
				// Setting the email content
				// Setting the email content
				$mail->IsHTML(true);
				$mail->Subject = "Employee Appraisal For ".ucfirst($ps)." Quarter ".ucfirst($f)." ".$from." to ".ucfirst($t)." ".$from;
				$mail->Body = '
				<body style="background-color:grey">
				<table align="center" border="0" cellpadding="0" cellspacing="0" width="550" bgcolor="white" style="border:2px solid black">
					<tbody>
						<tr>
							<td align="center">
								<table align="center" border="0" cellpadding="0" cellspacing="0" class="col-550" width="550">
									<tbody>
										<tr>
											<td align="center" style="background-color: #4cb96b;
													   height: 50px;">
			
												<a href="#" style="text-decoration: none;">
													<p style="color:white;
															  font-weight:bold;">
															  EMPLOYEE APPRAISAL FOR '.strtoupper($f).'('.$from.')-'.strtoupper($t).'('.$from.')
													</p>
												</a>
											</td>
										</tr>
									</tbody>
								</table>
							</td>
						</tr>
						
			
						<tr style="display: inline-block;">
							<td style="height: 150px;
									   padding: 20px;
									   border: none; 
									   border-bottom: 2px solid #361B0E;
									   background-color: white;">
			
								<h5 style="text-align: left;
										   align-items: center;">
										   Dear All,<br><br>

										   Please find the below Performance Appraisal Link for the '.$ps.' quarter ('.$f.' '.$from.' to '.$t.' '.$from.')<br><br>
										   
										   Kindly update all the data in your MP and complete the appraisal process on or before '.date('d-m-Y',strtotime($due_date)).'.<br><br>
										   
										   Internal users:<br><br>
										   
										   http://192.168.1.236/epes/login.php<br><br><br>
										   
										   User Name: Your employee Code (Eg:123)<br><br>
										   Password: 123456 (Note : Those who changed the password earlier can use the same password.)<br><br><br>
										   
										   Once you login kindly change the password immediately.<br><br>
										   Click at the top right corner and click manage account & change the password.<br><br>
										   
										   External Users:<br><br>
										   
										   https://epes.propelind.com:6072/login.php<br><br><br>
										   
										   User Name: Your employee Code (Eg:123)<br><br>
										   Password: 123456 (Note : Those who changed the password earlier can use the same password.)<br><br><br>
										   
										   Kindly circulate the mail for your teammates if anyone is missing.
								</h5>
								<!-- <p class="data" style="text-align: justify-all;
										  align-items: center; 
										  font-size: 15px;
										  padding-bottom: 12px;">
									Design Patterns….??? I think you have heard this name before in programming… Yes, you might have heard this name before in programming if you are…
								</p> -->
								<!-- <p>
									<a href="https://www.geeksforgeeks.org/design-patterns-a-must-skill-to-have-for-software-developers-in-2019/" style="text-decoration: none; 
											  color:black; 
											  border: 2px solid #4cb96b; 
											  padding: 10px 30px;
											  font-weight: bold;"> 
									   Read More 
								  </a>
								</p> -->
							</td>
						</tr>
					</tbody>
				</table>
			</body>
								';
				$mail->AltBody = 'Plain text message body for non-HTML email client. Gmail SMTP email body.';
				$mail->send();
				} 		
			}
		} }
			if($save == 1)
			return 1;
			else
			return 2;

	}
	function delete_task(){
		extract($_POST);

		$delete = $this->db->query("DELETE FROM task_list where id = $id");
		if($delete){
			return 1;
		}
	}
	function save_progress()
	{
	date_default_timezone_set("Asia/Kolkata");
	$ev_d = date('Y-m-d H:i:s');
	//$q = $this->db->query("SELECT * FROM employee_list where");
	$t = $_POST['task_id'];	
	$q = $this->db->query("SELECT * FROM task_list where id='$t'");
	$r = $q->fetch_array();
	$e = $r['employee_id'];
	extract($_POST);
	$qry8 = $this->db->query("SELECT * FROM employee_list WHERE employee_id=$e");
	$row8 = $qry8->fetch_array();
	$ev1 = $row8['evaluator_id'];
	$ev2 = $row8['evaluator2_id'];
	$qry88 = $this->db->query("SELECT * FROM employee_list WHERE employee_id=$ev1");
	$row88 = $qry88->fetch_array();
	$qry888 = $this->db->query("SELECT * FROM employee_list WHERE employee_id=$ev2");
	$row888 = $qry888->fetch_array();
	$qry9 = $this->db->query("SELECT * FROM task_list WHERE id=$t");
	$row9 = $qry9->fetch_array();
	if($_SESSION['login_employee_id'] == $e)
	{
	$prg = $_POST['ytd_target'];
		//print_r($prg);
	$sno = $_POST['sno'];$mps = $_POST['mpp']; 
	$contribution1 = $_POST['contribution'];
	$contribution = $this->db->real_escape_string($contribution1);
	$training1 = $_POST['training'];
	$training = $this->db->real_escape_string($training1);
	$feedback1 = $_POST['feedback'];
	$feedback = $this->db->real_escape_string($feedback1);
	//print_r($file);
	if(isset($_POST['is_complete']))
	$is_complete = 1;
	else
	$is_complete = 0;
	$q1 = $this->db->query("SELECT * FROM task_progress WHERE task_id=$task_id");
	$c1 = mysqli_num_rows($q1);
	foreach($prg as $k => $v)
    {
		//echo $k;
		//print_r($_FILES['file'.$k]['tmp_name']);
		$file = $_FILES['file'.$k]['name'];
		$countfiles = count($file);
		for($i=0;$i<$countfiles;$i++){
			$filename = $file[$i];
			if($filename != "") {
			$filename1 = $e.date('d-m-y').'up'.$file[$i];
			$filess = $this->db->real_escape_string($filename1);
			$this->db->query("INSERT INTO fileup(task_id,kpi_id,filename) VALUES ('$task_id','$sno[$k]','$filess')");
			move_uploaded_file($_FILES['file'.$k]['tmp_name'][$i],'uploaddoc/'.$filename1); }
		}

		$a = $this->db->real_escape_string($activities[$k]);
		$kp = $this->db->real_escape_string($kpi[$k]);	
		$u = $this->db->real_escape_string($uom[$k]);
		$qry1 = $this->db->query("SELECT * FROM apprisal_mop WHERE kpi_id=$sno[$k] AND task_id=$task_id");
		$count = mysqli_num_rows($qry1);
		$data = "";
		$data .= " task_id='$task_id' ";
		$data .= ", kpi_id='$sno[$k]' ";
		$data .= ", sno='$mps[$k]' ";
		$data .= ", activities='$a' ";
		$data .= ", kpi='$kp' ";
		$data .= ", uom='$u' ";
		$data .= ", ly_actual='$ly_actual[$k]' ";
		$data .= ", target='$target[$k]' ";
		$data .= ", actual='$actual[$k]' ";
		$data .= ", ytd_target='$v' ";
		$data .= ", target_ach='$target_ach[$k]' ";
		$data .= ", ach75='$ach75[$k]' ";
		$data .= ", ytd_actual='$ytd_actual[$k]' ";
		$data .= ", growth_ly='$growth_ly[$k]' ";
		$data .= ", variance='$variance[$k]' ";
		$data .= ", cal='$cal[$k]' ";
		if($count <= 0)
		$save = $this->db->query("INSERT INTO apprisal_mop set $data");
		else
		$save = $this->db->query("UPDATE apprisal_mop set $data where task_id = $task_id AND kpi_id =$sno[$k]");	
	}
	for($i=1;$i<=10;$i++)
{
        if(isset($_POST["self_".$i]))
        {
		$self = $_POST["self_".$i];
		$qry1 = $this->db->query("SELECT * FROM apprisal_rate WHERE task_id=$task_id AND traits_no=$i");
		$count = mysqli_num_rows($qry1);
		$data = "";
		$data .= " task_id='$task_id' ";
		$data .= ", traits_no='$i' ";
		$data .= ", self='$self' ";
        
		$value = $_POST["self_".$i];
        //echo "value = ".$value;
		if($count <= 0)
		$save = $this->db->query("INSERT INTO apprisal_rate set $data");
		else
		$save = $this->db->query("UPDATE apprisal_rate set $data where task_id = $task_id AND traits_no =$i");	
	
        }
       
    }			
	$data = "";
	$data .= " task_id='$task_id' ";
	$data .= ", contribution='$contribution' ";
	$data .= ", training='$training' ";
	$data .= ", feedback='$feedback' ";
	$data .= ", is_complete='$is_complete' ";
	if($c1 <= 0)
	$save = $this->db->query("INSERT INTO task_progress set $data");
	else
	$save = $this->db->query("UPDATE task_progress set $data where task_id = $task_id");	
	
	if($save){
		if(!isset($_POST['is_complete'])) {
			$this->db->query("UPDATE task_list set status = 1 where id = $task_id ");
		}
		else if(isset($_POST['is_complete'])){
			
			$this->db->query("UPDATE task_list set status = 2, completed='$ev_d' where id = $task_id ");
			//echo "SELECT * FROM employee_list WHERE employee_id=$e";					
    		
			if($row8['email'] != "")
			{
			$mail = new PHPMailer(true);    // Server settings
    		//$mail->SMTPDebug = SMTP::DEBUG_SERVER; // for detailed debug output
    		$mail->isSMTP();
    		$mail->Host = 'zimbra.propelind.com';
    		$mail->SMTPAuth = true;
    		$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    		$mail->Port = 587;
    		$mail->Username = 'larancy@propelind.com'; // YOUR gmail email
    		$mail->Password = '@LOpel@123'; // YOUR gmail password
    		// Sender and recipient settings
    		$mail->setFrom('barani@propelind.com', 'Baranikumar - HR');
    		$mail->addAddress($row8['email'], $row8['firstname']);
    		$mail->addReplyTo('barani@propelind.com', 'Baranikumar - HR'); // to set the reply to
		    // Setting the email content
    		$mail->IsHTML(true);
    		$mail->Subject = "Appraisal Form";
    		$mail->Body = '
			<body style="background-color:grey">
			<table align="center" border="0" cellpadding="0" cellspacing="0" width="550" bgcolor="white" style="border:2px solid black">
				<tbody>
					<tr>
						<td align="center">
							<table align="center" border="0" cellpadding="0" cellspacing="0" class="col-550" width="550">
								<tbody>
									<tr>
										<td align="center" style="background-color: #4cb96b;
												   height: 50px;">
		
											<a href="#" style="text-decoration: none;">
												<p style="color:white;
														  font-weight:bold;">
													Appraisal Portal
												</p>
											</a>
										</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
					<tr style="height: 100px;">
						<td align="center" style="border: none;
								   border-bottom: 2px solid #4cb96b; 
								   padding-right: 20px;padding-left:20px"><br>
							<p style="font-weight: bolder;font-size: 35px;
									  letter-spacing: 0.025em;
									  color:black;">
								Hello '.$row8['firstname'].' .!
								<br> '.$row9['task'].' '.$row9['year_from'].' - '.$row9['year_to'].'
							</p><br>
						</td>
					</tr>
		
					<tr style="display: inline-block;">
						<td style="height: 150px;
								   padding: 20px;
								   border: none; 
								   border-bottom: 2px solid #361B0E;
								   background-color: white;">
		
							<h5 style="text-align: left;
									   align-items: center;">
								You have successfully completed your appraisal form for '.$row9['task'].' '.$row9['year_from'].' - '.$row9['year_to'].' '.$row9['mode'].'('.$row9['pperiod'].')...
								<br><br>Cheers, <br>HR Team
							</h5>							
						</td>
					</tr>
				</tbody>
			</table>
		</body>
							';
		    //$mail->send();			
			$mail->ClearAddresses();

			$mail->addAddress($row88['email'], $row88['firstname']);
			$mail->Body = '
			<body style="background-color:grey">
			<table align="center" border="0" cellpadding="0" cellspacing="0" width="550" bgcolor="white" style="border:2px solid black">
				<tbody>
					<tr>
						<td align="center">
							<table align="center" border="0" cellpadding="0" cellspacing="0" class="col-550" width="550">
								<tbody>
									<tr>
										<td align="center" style="background-color: #4cb96b;
												   height: 50px;">
		
											<a href="#" style="text-decoration: none;">
												<p style="color:white;
														  font-weight:bold;">
													Appraisal Portal
												</p>
											</a>
										</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
					<tr style="height: 100px;">
						<td align="center" style="border: none;
								   border-bottom: 2px solid #4cb96b; 
								   padding-right: 20px;padding-left:20px"><br>
							<p style="font-weight: bolder;font-size: 35px;
									  letter-spacing: 0.025em;
									  color:black;">
								Hello '.$row88['firstname'].' .!
								<br> '.$row8['firstname'].' '.$row8['lastname'].' Completed the task.
							</p><br>
						</td>
					</tr>
		
					<tr style="display: inline-block;">
						<td style="height: 150px;
								   padding: 20px;
								   border: none; 
								   border-bottom: 2px solid #361B0E;
								   background-color: white;">
		
							<h5 style="text-align: left;
									   align-items: center;">
									   <p style="text-transform:uppercase">Employee Id 	 :  '.$row8['employee_id'].'</p>
									   <p style="text-transform:uppercase">Employee Name :  '.$row8['firstname'].  '  '.$row8['lastname'].'</p>
									   <p style="text-transform:uppercase">Appraisal     :  '.$row9['task'].' '.$row9['year_from'].' - '.$row9['year_to'].' '.$row9['mode'].'('.$row9['pperiod'].')...<p>
									   The above employee appraisal form has been completed and submitted on their portal. Now you can evaluate the form.
									   <br>
								<p> <a href="http://192.168.1.236/epes/">http://192.168.1.236/epes/</a></p>
								<br><br>Cheers, <br>HR Team
							</h5>							
						</td>
					</tr>
				</tbody>
			</table>
		</body>
							';
		    //$mail->send();	
			} 
			
		}		
			return 1;
	}
		// if($save){
		// 	return 1;
		// }
	}
	else if($_SESSION['login_employee_id'] != $e)
	{
	$is_per = $_POST['is_per'];
	if(isset($_POST['is_reason'])){
	$is_reason = $_POST['is_reason'];
	}else { $is_reason=""; }
	$hod_per =0;$h_by=0;
	if(isset($_POST['hod_per']))
	{
	$hod_per = $_POST['hod_per'];
	$h_by = $_SESSION['login_employee_id'];
	}
	if(isset($_POST['actual1']))
	{
	$actual1 = $_POST['actual1'];
	$ytd_app = $_POST['ytd_actual1'];
	$growth_ly = $_POST['growth_ly'];
	$variance = $_POST['variance'];
	$target_ach = $_POST['target_ach'];
	$ach75 = $_POST['ach75'];
	$sno = $_POST['sno'];
	foreach($ytd_app as $k => $v)
	{
		$save = $this->db->query("UPDATE apprisal_mop set actual1=$actual1[$k],ytd_actual1 = $v,growth_ly1='$growth_ly[$k]',variance1=$variance[$k],target_ach1=$target_ach[$k],ach1_75=$ach75[$k] where task_id = $task_id AND kpi_id =$sno[$k]");	
	}
	}
	
	if(isset($_POST['is_reason']))
	{
	$ev_d = date('Y-m-d H:i:s');
	$data = "";
	$data .= " status1=1 ";
	$data .= ", ev_by= {$_SESSION['login_employee_id']} ";
	$data .= ", ev_date='$ev_d' ";
	$save = $this->db->query("UPDATE task_list set $data where id = $task_id");
	}
	if(!isset($_POST['hod_per'])){
	//$save = $this->db->query("UPDATE task_list set $data where id = $task_id");
	if($row888['email'] != "")
			{
	$mail = new PHPMailer(true);    // Server settings
    		//$mail->SMTPDebug = SMTP::DEBUG_SERVER; // for detailed debug output
    		$mail->isSMTP();
    		$mail->Host = 'zimbra.propelind.com';
    		$mail->SMTPAuth = true;
    		$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    		$mail->Port = 587;
    		$mail->Username = 'larancy@propelind.com'; // YOUR gmail email
    		$mail->Password = '@LOpel@123'; // YOUR gmail password
    		// Sender and recipient settings
    		$mail->setFrom('barani@propelind.com', 'Baranikumar - HR');
    		$mail->addAddress($row888['email'], $row888['firstname']);
    		$mail->addReplyTo('barani@propelind.com', 'Baranikumar - HR'); // to set the reply to
		    // Setting the email content
    		$mail->IsHTML(true);
    		$mail->Subject = "Appraisal Form";
    		$mail->Body = '
			<body style="background-color:grey">
			<table align="center" border="0" cellpadding="0" cellspacing="0" width="550" bgcolor="white" style="border:2px solid black">
				<tbody>
					<tr>
						<td align="center">
							<table align="center" border="0" cellpadding="0" cellspacing="0" class="col-550" width="550">
								<tbody>
									<tr>
										<td align="center" style="background-color: #4cb96b;
												   height: 50px;">
		
											<a href="#" style="text-decoration: none;">
												<p style="color:white;
														  font-weight:bold;">
													Appraisal Portal
												</p>
											</a>
										</td>
									</tr>
								</tbody>
							</table>
						</td>
					</tr>
					<tr style="height: 100px;">
						<td align="center" style="border: none;
								   border-bottom: 2px solid #4cb96b; 
								   padding-right: 20px;padding-left:20px"><br>
							<p style="font-weight: bolder;font-size: 35px;
									  letter-spacing: 0.025em;
									  color:black;">
								Hello '.$row888['firstname'].' .!
								<br> Waiting for Your Approval.
							</p><br>
						</td>
					</tr>
		
					<tr style="display: inline-block;">
						<td style="height: 150px;
								   padding: 20px;
								   border: none; 
								   border-bottom: 2px solid #361B0E;
								   background-color: white;">
		
							<h5 style="text-align: left;
									   align-items: center;">
									   <p style="text-transform:uppercase">Employee Id 	 :  '.$row8['employee_id'].'</p>
									   <p style="text-transform:uppercase">Employee Name :  '.$row8['firstname'].  '  '.$row8['lastname'].'</p>
									   <p style="text-transform:uppercase">Appraisal     :  '.$row9['task'].' '.$row9['year_from'].' - '.$row9['year_to'].' '.$row9['mode'].'('.$row9['pperiod'].')...<p>
									   <p style="text-transform:uppercase">Evaluated by  :  '.$row88['firstname'].  '  '.$row88['lastname'].'</p>
									   The above employee appraisal form has been evaluated and is waiting for your approval. Update your status to complete the form.
									   <br>
								<p> <a href="http://192.168.1.236/epes/">http://192.168.1.236/epes/</a></p>
								<br><br>Cheers, <br>HR Team
							</h5>							
						</td>
					</tr>
				</tbody>
			</table>
		</body>
							';
		    //$mail->send();	
			}
	}
	$qry_rt = $this->db->query("SELECT * FROM ratings WHERE task_id=$task_id");
	$count_rt = mysqli_num_rows($qry_rt);
	$qry8 = $this->db->query("SELECT * FROM task_list WHERE id=$task_id");
	$row8 = $qry8->fetch_array();
	$emp = $row8['employee_id'];
	$data1 = "";
	$data1 .= " employee_id='$emp' ";
	$data1 .= ", task_id='$task_id' ";
	if(isset($_POST['is_reason'])) {
	$data1 .= ", evaluator_id = {$_SESSION['login_employee_id']} ";
	$data1 .= ", is_per='$is_per' ";
	$data1 .= ", is_reason='$is_reason' ";
	}
	if(isset($_POST['hod_per'])) {
	$data1 .= ", hod_per='$hod_per' ";
	$data1 .= ", hod_reason='$hod_reason' ";
	$data1 .= ", hstatus_by='$h_by' ";
	$data1 .= ", hstatus_date='$ev_d' ";
	}
	
	if($count_rt <= 0)
	{
	$this->db->query("UPDATE task_list set status1=1 where id = $task_id"); $save = $this->db->query("INSERT INTO ratings set $data1");
	}
	else
	{
	$save = $this->db->query("UPDATE ratings set $data1 where task_id = $task_id");	
	}

	// echo "UPDATE task_list set $data where id = $task_id";
	$save = 0;
	for($i=1;$i<=10;$i++)
	{
			if(isset($_POST["appr_".$i]))
			{
			$data = "";
			$appr = $_POST["appr_".$i];
			$data .= " appraiser='$appr' ";			
			//$value = $_POST["self_".$i];
			//echo "value = ".$value;
			$save = $this->db->query("UPDATE apprisal_rate set $data where task_id = $task_id AND traits_no =$i");	
		
			}		   
		} 
		if($save == 1)
		{	
			return 1;
		}
		else if(!$save)
		{
			return 1;
		}
		else 
		{
			return 3;
		}
	}
	}
	
	function delete_progress(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM task_progress where id = $id");
		if($delete){
			return 1;
		}
	}
	function save_evaluation(){
		extract($_POST);
		//print_r($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$data .= ", evaluator_id = {$_SESSION['login_id']} ";
		if(empty($id)){
			$save = $this->db->query("INSERT INTO ratings set $data");
		}else{
			$save = $this->db->query("UPDATE ratings set $data where id = $id");
		}
		if($save){
		if(!isset($is_complete))
			return 1;
		}
	}
	function delete_evaluation(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM ratings where task_id = $id");
		if($delete){
			return 1;
		}
	}
	function get_emp_tasks(){
		extract($_POST);
		if(!isset($task_id))
		$get = $this->db->query("SELECT * FROM task_list where employee_id = $employee_id and status = 2 and id not in (SELECT task_id FROM ratings) ");
		else
		$get = $this->db->query("SELECT * FROM task_list where employee_id = $employee_id and status = 2 and id not in (SELECT task_id FROM ratings where task_id !='$task_id') ");
		$data = array();
		while($row=$get->fetch_assoc()){
			$data[] = $row;
		}
		return json_encode($data);
	}
	function get_progress(){
		extract($_POST);
		$get = $this->db->query("SELECT p.*,concat(u.firstname,' ',u.lastname) as uname,u.avatar FROM task_progress p inner join task_list t on t.id = p.task_id inner join employee_list u on u.employee_id = t.employee_id where p.task_id = $task_id order by unix_timestamp(p.date_created) desc ");
		$data = array();
		while($row=$get->fetch_assoc()){
			$row['uname'] = ucwords($row['uname']);
			$row['progress'] = html_entity_decode($row['progress']);
			$row['date_created'] = date("M d, Y",strtotime($row['date_created']));
			$data[] = $row;
		}
		return json_encode($data);
	}
	function get_report(){
		extract($_POST);
		$data = array();
		$get = $this->db->query("SELECT t.*,p.name as ticket_for FROM ticket_list t inner join pricing p on p.id = t.pricing_id where date(t.date_created) between '$date_from' and '$date_to' order by unix_timestamp(t.date_created) desc ");
		while($row= $get->fetch_assoc()){
			$row['date_created'] = date("M d, Y",strtotime($row['date_created']));
			$row['name'] = ucwords($row['name']);
			$row['adult_price'] = number_format($row['adult_price'],2);
			$row['child_price'] = number_format($row['child_price'],2);
			$row['amount'] = number_format($row['amount'],2);
			$data[]=$row;
		}
		return json_encode($data);

	}
	function get_dept_id(){
		$dept = $_POST["dept"];
		?>
		<div class="form-group">
						<label for="">Assign To</label>
						<select name="employee_id[]" id="employee_id" class="form-control form-control-sm" required="" multiple="multiple">
							<?php 
							$employees = $this->db->query("SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where department_id=$dept and doe='0000-00-00' order by concat(firstname,' ',lastname) asc");
							while($row=$employees->fetch_assoc()):
							?>
							<option value="<?php echo $row['employee_id'] ?>" selected><?php echo $row['name'].' - '.$row['employee_id'] ?></option>
							<?php endwhile; ?>
						</select>
					</div>
		<?php
	}
	function get_dept_ids(){
		$dept = $_POST["dept"];
		?>
		          <div class="form-group">
						<label for="">Assign To</label>
						<select name="employee_id" id="employee_id" class="form-control form-control-sm select2" required="" onchange="employee();">
						
							<?php 
							$ev_id = $_SESSION['login_employee_id'];
							if($_SESSION['login_type']==1){
								//echo "SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where department_id=$dept and doe='0000-00-00' and (evaluator_id=$ev_id or evaluator2_id=$ev_id) order by concat(firstname,' ',lastname) asc";
							$employees = $this->db->query("SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where department_id=$dept and doe='0000-00-00' and (evaluator_id=$ev_id or evaluator2_id=$ev_id) order by concat(firstname,' ',lastname) asc");
							} else{
								//echo "SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where department_id=$dept and doe='0000-00-00' and employee_id!={$_SESSION['login_employee_id']} order by concat(firstname,' ',lastname) asc";
							$employees = $this->db->query("SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where department_id=$dept and doe='0000-00-00' and employee_id!={$_SESSION['login_employee_id']} order by concat(firstname,' ',lastname) asc");
	
							}
							while($row=$employees->fetch_assoc()):
							?>
							<option value="<?php echo $row['employee_id'] ?>" selected><?php echo $row['name'] .' - '.$row['employee_id']?></option>
							<?php endwhile; ?>
							<option value="0" selected>Select Employee</option>
						</select>
					</div>
		<?php
	}
	function add_more(){
		?>
	<tr class="txtMult">
		<td align="center" class="text-danger"><button type="button" data-toggle="tooltip" data-placement="right" title="Click To Remove" onclick="if(confirm('Are you sure to remove?')){$(this).closest('tr').remove();}" class="btn btn-danger"><i class="fa fa-fw fa-trash-alt"></i></button></td>
		<td><input type="text" name="sno[]" class="form-control"></td>
		<td align="center"><textarea class="form-control" name="activities[]"></textarea></td>
		<td><textarea class="form-control" name="kpi[]"></textarea></td>
		<td><input type="text" name="uom[]" class="form-control"></td>
		<!-- <td><input type="text" name="ly_actual[]" class="form-control"></td> -->
		<td><input type="text" name="ytd_target[]" class="form-control ytd"></td>
		<td><input type="text" name="q1_target[]" class="form-control q1" onkeyup="cal();"></td>
		<td><input type="text" name="q2_target[]" class="form-control q2" onkeyup="cal();"></td>
		<td><input type="text" name="q3_target[]" class="form-control q3" onkeyup="cal();"></td>
		<td><input type="text" name="q4_target[]" class="form-control q4" onkeyup="cal();"></td>
		<td><input type="text" name="ytd_value[]" class="form-control y"></td>
		<td></td>
		<!-- <td><input type="text" name="ytd_actual[]" class="form-control"></td> -->
		<!-- <td><input type="text" name="growth_ly[]" class="form-control"></td> -->
		<!-- <td><input type="text" name="variance[]" class="form-control"></td> -->

	</tr>
	<?php
	echo '|***|addmore';
	}
	function get_mop(){
		$emp = $_POST["emp"];
		$result	=	$this->db->query("SELECT * FROM kpi_mster where employee_id=$emp and status=0");
		if($result->num_rows>0){
			$s	=	'';
			while($val  =   $result->fetch_assoc()){
				$kpi_id = $val['id'];
				$s++;  ?>
			<tr id="<?php echo $val['id']; ?>">
				<td><?php echo $val['id']; ?></td>
				<td></td>
				<td align="center"><?=$val['sno']?></td>
				<td><?=$val['activities']?></td>
				<td><?=$val['kpi']?></td>
				<td><?=$val['uom']?></td>
				<!-- <td><?=$val['ly_actual']?></td> -->
				<td class="yt"><?=$val['ytd_target']?></td>
				<td><?=$val['q1_target']?></td>
				<td><?=$val['q2_target']?></td>
				<td><?=$val['q3_target']?></td>
				<td><?=$val['q4_target']?></td>
				<td><?=$val['ytd_value']?></td>
				<td><input type="checkbox" name="dw" onclick="chss(<?=$val['id']?>)" <?php if($val['cal'] == 1) { echo "checked"; } ?>/></td>
				<td><button type="button" class="btn btn-danger btn-flat delete_kpi" onclick="return del(<?php echo $kpi_id;?>)">
		                          <i class="fa fa-fw fa-trash-alt"></i>
		                        </button></td>
			</tr>
			<?php
			}
			
		}else{ ?>
		<tr>
			<td colspan="7" class="bg-light text-center"><strong>No Record(s) Found!</strong></td>
		</tr>
		<?php } 
	}
	function save_mop()
	{
		extract($_POST);
		$prg = $_POST['activities'];
		$emp = $_POST['employee_id'];
		$qry1 = $this->db->query("SELECT * FROM kpi_mster WHERE employee_id=$emp");
		$count = mysqli_num_rows($qry1);		
		foreach($prg as $k => $v)
    {	
		$count+=1;
		$a = $this->db->real_escape_string($v);
		$kp = $this->db->real_escape_string($kpi[$k]);	
		$u = $this->db->real_escape_string($uom[$k]);	
		$data = "";
		//$data .= " task_id='$task_id' ";
		$data .= " sno='$sno[$k]' ";
		$data .= ", employee_id='$emp' ";
		$data .= ", activities='$a' ";
		$data .= ", kpi='$kp' ";
		$data .= ", uom='$u' ";
		// $data .= ", ly_actual='$ly_actual[$k]' ";
		$data .= ", q1_target='$q1_target[$k]' ";
		$data .= ", q2_target='$q2_target[$k]' ";
		$data .= ", q3_target='$q3_target[$k]' ";
		$data .= ", q4_target='$q4_target[$k]' ";
		$data .= ", ytd_target='$ytd_target[$k]' ";	
		$data .= ", ytd_value='$ytd_value[$k]' ";	
		//$data .= ", ytd_actual='$ytd_actual[$k]' ";
		// $data .= ", growth_ly='$growth_ly[$k]' ";
		//$data .= ", variance='$variance[$k]' ";
		if(!empty($v))
		$save = $this->db->query("INSERT INTO kpi_mster set $data");
			}
		if($save)
		{
			return 1;
		}
		else
		{
			return 2;
		}
	}
	function live_edit(){
		echo "sdfsdfdsfsd";
		$input = filter_input_array(INPUT_POST);
		$update_field='';
		if(isset($input['sno'])) {
			$update_field.= "sno='".$input['sno']."'";
		}
	else if(isset($input['activities'])) {
		$update_field.= "activities='".$this->db->real_escape_string($input['activities'])."'";
	} else if(isset($input['kpi'])) {
		$update_field.= "kpi='".$this->db->real_escape_string($input['kpi'])."'";
	} else if(isset($input['uom'])) {
		$update_field.= "uom='".$this->db->real_escape_string($input['uom'])."'";
	} else if(isset($input['ytd_target'])) {
		$update_field.= "ytd_target='".$input['ytd_target']."'";
	}
	else if(isset($input['q1_target'])) {
		$update_field.= "q1_target='".$input['q1_target']."'";
	}
	else if(isset($input['q2_target'])) {
		$update_field.= "q2_target='".$input['q2_target']."'";
	}
	else if(isset($input['q3_target'])) {
		$update_field.= "q3_target='".$input['q3_target']."'";
	}
	else if(isset($input['q4_target'])) {
		$update_field.= "q4_target='".$input['q4_target']."'";
	}
	else if(isset($input['ytd_value'])) {
		$update_field.= "ytd_value='".$input['ytd_value']."'";
	}	
	if($update_field && $input['id']) {
		$sql_query = $this->db->query("UPDATE kpi_mster SET $update_field WHERE id='" . $input['id'] . "'");	
	}
	}
	function delete_kpi(){
		extract($_POST);
		$delete = $this->db->query("UPDATE kpi_mster SET status=1 where id = $id");
		if($delete){
			return 1;
		}
	}
	function get_reports(){
		print_r($_POST);
		$type = $_SESSION['login_type'];
		$ev_id = $_SESSION['login_employee_id'];
		if($type !=2 )$hod_dept = $_SESSION['login_hod_dept']; 
		$emp = $_POST["emp"];
		$dept = $_POST["dept"];
		$year = $_POST["year"];
		$mode = $_POST["mode"];
		$period = $_POST["period"];
		$range = $_POST["range"];
		$status = $_POST["status"];
		$range = $_POST['range'];
		$s = explode('-', $range);
		//search individuals
		$ids = "";
		$ids .= 0;
		if($type == 1)
		$r = $this->db->query("SELECT * FROM employee_list WHERE (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
		else if($type == 3)
		$r = $this->db->query("SELECT * FROM employee_list WHERE department_id IN ($hod_dept)");
		else if($type == 2)
		$r = $this->db->query("SELECT * FROM employee_list");
		while($vals  =   $r->fetch_assoc()){
			$ids .= ",".$vals['employee_id'];
		}
		if($emp == 0 && $dept != 0 && $year == 0 && $period != '0' && $range == 0 && $status == 0)
		{ echo "0";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.pperiod='$period' 
		");
		}
		else if($emp == 0 && $dept != 0 && $year == 0 && $mode == 0 && $period == 0 && $range == 0 && $status == 0)
		{
			echo "1";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) order by employee_id
		");
		}
		else if($emp == 0 && $dept != 0 && $year == 0 && $mode == 0 && $period == 0 && $range == 0 && $status != '0')
		{ echo "2";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept != 0 && $year != 0 && $period != '0' && $range == 0 && $status != '0')
		{ echo "3";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and a.pperiod='$period' and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept != 0 && $year != 0 && $period == 0 && $range == 0 && $status != '0')
		{ echo "4";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept != 0 && $year != 0 && $period != '0' && $range == 0 && $status != '0')
		{ echo "5";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and a.pperiod='$period' and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept != 0 && $year != 0 && $period != '0' && $range == 0 && $status == 0)
		{ echo "6";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and a.pperiod='$period' 
		");
		}
		else if($emp == 0 && $dept != 0 && $year != 0 && $mode == 0 && $period == 0 && $range == 0 && $status == 0)
		{ echo "7";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year
		");
		}
		else if($emp == 0 && $dept != 0 && $year == 0 && $mode == '0' && $period == '0' && $range != '0' && $status == 0)
		{ echo "8";
			$ids = "";
			$ids .= 0;
			if($type == 1)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept and (evaluator_id=$ev_id or evaluator2_id=$ev_id)");
			else if($type == 3)
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			else
			$r = $this->db->query("SELECT * FROM employee_list WHERE department_id=$dept");
			while($vals  =   $r->fetch_assoc()){
				$ids .= ",".$vals['employee_id'];
			}			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and b.is_per BETWEEN $s[0] and $s[1]
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $period != '0' && $range != '0' && $status == '0')
		{			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year and a.pperiod='$period' and b.is_per BETWEEN $s[0] and $s[1]
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $period != '0' && $range != '0' && $status != '0')
		{			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year and a.pperiod='$period' and b.hod_per='$status' and b.is_per BETWEEN $s[0] and $s[1]
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $period != '0' && $range == 0 && $status != '0')
		{			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year and a.pperiod='$period' and b.hod_per='$status'
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $period == 0 && $range == 0 && $status != '0')
		{			
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year and b.hod_per='$status'
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $period != '0' && $range == 0 && $status != '0')
		{
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year and a.pperiod='$period' and b.hod_per='$status'
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $period != '0' && $range == 0 && $status == 0)
		{
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year and a.pperiod='$period'
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $mode == 0 && $period == 0 && $range == 0 && $status == 0)
		{
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year
		");
		}
		else if($emp != 0 && $dept != 0 && $year != 0 && $mode == 0 && $period == 0 && $range != '0' && $status == 0)
		{
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.year_from=$year and b.is_per BETWEEN $s[0] and $s[1]
		");
		}
		else if($emp != 0 && $dept != 0 && $year == 0 && $period != '0' && $range == 0 && $status == 0)
		{
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and a.pperiod='$period'
		");
		}
		else if($emp != 0 && $dept != 0 && $year == 0 && $period == '0' && $range != '0' && $status == 0)
		{
			$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and b.is_per BETWEEN $s[0] and $s[1]
		");
		}
		else if($emp != 0 && $dept != 0 && $year == 0 && $mode == 0 && $period == 0 && $range == 0 && $status == 0)
		{
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp
		");
		}
		
		else if($emp != 0 && $dept != 0 && $year == 0 && $mode == 0 && $period == 0 && $range == 0 && $status != '0')
		{
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id=$emp and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode != '0' && $period != '0' && $range == 0 && $status == '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and a.pperiod='$period'
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode != '0' && $period != '0' && $range != '0' && $status == '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and a.pperiod='$period' and b.is_per BETWEEN $s[0] and $s[1]
		");
		}
		else if($emp == 0 && $dept == 0 && $year == 0 && $mode != '0' && $period != '0' && $range != '0' && $status == '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.pperiod='$period' and b.is_per BETWEEN $s[0] and $s[1]
		");
		}
		else if($emp == 0 && $dept == 0 && $year == 0 && $mode != '0' && $period != '0' && $range == '0' && $status != '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.pperiod='$period' and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode != '0' && $period != '0' && $range != '0' && $status != '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and a.pperiod='$period' and b.is_per BETWEEN $s[0] and $s[1] and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode == 0 && $period == 0 && $range != '0' && $status != '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and b.is_per BETWEEN $s[0] and $s[1] and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode == 0 && $period == 0 && $range == 0 && $status == '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year
		");
		}
		else if($emp == 0 && $dept == 0 && $year == 0 && $period != '0' && $range == 0 && $status == '0')
		{		
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.pperiod='$period'
		");
		}
		else if($emp == 0 && $dept == 0 && $year == 0 && $mode == 0 && $period == '0' && $range == 0 && $status != '0')
		{			
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode == 0 && $period == '0' && $range == 0 && $status != '0')
		{
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and b.hod_per='$status'
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode != '0' && $period != '0' && $range == 0 && $status != '0')
		{
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and b.hod_per='$status' and a.pperiod='$period' 
		");
		}
		else if($emp == 0 && $dept == 0 && $year == 0 && $mode == '0' && $period == '0' && $range != '0' && $status == '0')
		{
			echo "SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and b.is_per BETWEEN $s[0] and $s[1]";
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and b.is_per BETWEEN $s[0] and $s[1] 
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode == '0' && $period == '0' && $range != '0' && $status == '0')
		{		
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and b.is_per BETWEEN $s[0] and $s[1] 
		");
		}
		else if($emp == 0 && $dept == 0 && $year != 0 && $mode != '0' && $period != '0' && $range != '0' && $status == '0')
		{		
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,b.is_per,b.hod_per,b.is_reason,b.hod_reason,concat(c.firstname,' ',c.lastname) as name from task_list a,ratings b,employee_list c where a.id=b.task_id and a.employee_id=b.employee_id and a.employee_id=c.employee_id and a.employee_id IN ($ids) and a.year_from=$year and a.pperiod='$period' and b.is_per BETWEEN $s[0] and $s[1] 
		");
		}
		else
		{
			?>
			<tr>
			<td colspan="12" class="bg-light text-center"><strong>No Record(s) Found!</strong></td>
			</tr>
			<?php
			exit();
		}
		if($result->num_rows>0){
			$s	=	'';
				while($val  =   $result->fetch_assoc()){
				$id = $val['id'];
				
				$qry888 = $this->db->query("SELECT * FROM task_progress WHERE task_id=$id");
				$row888 = $qry888->fetch_array();
$qry88 = $this->db->query("SELECT * FROM ratings WHERE task_id=$id");
$row88 = $qry88->fetch_array();
//calculation for KPI
$qr = $this->db->query("SELECT SUM(ytd_actual) as ac_sum FROM apprisal_mop WHERE task_id=$id");
$rs = $qr->fetch_array();
$kpi_cal = round(($rs['ac_sum']/100)*75, 2);

$qrs1 = $this->db->query("SELECT SUM(ytd_actual1) as ac_sum FROM apprisal_mop WHERE task_id=$id");
$rss1 = $qrs1->fetch_array();
$kpi_cal1 = round(($rss1['ac_sum']/100)*75, 2);
//Calculation for self traits
$qr1 = $this->db->query("SELECT SUM(self) as self_sum FROM apprisal_rate WHERE task_id=$id");
$rs1 = $qr1->fetch_array();
$self_cal = round(($rs1['self_sum']/50)*25, 2);
//Calculation for Approver traits
$qr2 = $this->db->query("SELECT SUM(appraiser) as app_sum FROM apprisal_rate WHERE task_id=$id");
$rs2 = $qr2->fetch_array();
$app_cal = round(($rs2['app_sum']/50)*25, 2);
//total for self percentage
$total_self = $kpi_cal + $self_cal;
//total for Approver percentage
$total_app = $kpi_cal1 + $app_cal;
//echo round($kpi_cal, 2);
?>
				//calculation for KPI

				//echo round($kpi_cal, 2);
				
				$s++;  ?>
			<tr>
				<td><?php echo $val['id']; ?></td>
				<td align="center"><b><?=$val['name']." - ".$val['employee_id'];?></b></td>
				<td><b style='color:green'><?=$val['task'].' '.$val['year_from'].' - '.$val['year_to']?>&nbsp;<?=$val['mode'].' - '.$val['pperiod']?></b></td>
                <td><b style="color:blue;"><?=number_format($kpi_cal,1)?>%</b></td>
				<td><b style="color:blue;"><?=number_format($self_cal,1)?>%</b></td>
				<td><b style="color:blue;"><?=number_format($kpi_cal1,1)?>%</b></td>
				<td><b style="color:blue;"><?=number_format($app_cal,1)?>%</b></td>
				<td><b style="color:red;"><?=number_format($total_self,1)?>%</b></td>
				<td><b style="color:red;"><?=number_format($val['is_per'],1)?>%</b></td>
				<td><?php if($val['hod_per'] == 1) echo "<p style='color:green'><b>Approved</b></p>"; else echo "<p style='color:red'><b>Not Approved</b></p>";?><p style="color: blue;font-size:12px;"></p></td>
				<td><?=$val['hod_reason']?></td>
				<td><b><?=$row888['training']?></td>
				
			</tr>
			<?php
			}
		}else{ ?>
		<tr>
			<td colspan="12" class="bg-light text-center"><strong>No Record(s) Found!</strong></td>
		</tr>
		<?php } 
	}
	function get_uploads()
	{
		
		$tid = $_POST['taskid']; 
		$kpi = $_POST['kpi']; 
		$qry888 = $this->db->query("SELECT * FROM kpi_mster WHERE id=$kpi");
		$row888 = $qry888->fetch_array();
		$r = $this->db->query("SELECT * FROM fileup WHERE task_id=$tid and kpi_id=$kpi");
		?><input type="hidden" id="t" value="<?=$tid?>"/><input type="hidden" id="k" value="<?=$kpi?>"/><p style="color:green;font-weight:bold;">KPI : <?=$row888['activities']?> </p><table border="0" class="table"><?php
		if($r->num_rows > 0)
		{
		while($vals  =   $r->fetch_assoc()){
			?>
				<tr>
					<td style="color:blue"><?=$vals['filename'];?></td>
					<?php if($_SESSION['login_employee_id'] == $row888['employee_id']) { ?>
					<td><i class="fa fa-trash" style="color:red;" onclick="return del(<?=$vals['id'];?>)"></i></td>
					<?php } ?>
					<?php if($_SESSION['login_employee_id'] != $row888['employee_id']) { ?>
					<td><a href="uploaddoc/<?=$vals['filename'];?>" target="_blank"><i class="fa fa-download" style="color:green;"></i></a></td>
				<?php } ?>
				</tr>
				<?php
		} }
		else
		{
			?>
			<tr>
				<td colspan="3"><p style="color:red;font-weight:bold;font-size:10px;">No Uploads</p></td>
			</tr>
			<?php
		}		
		?></table><?php
	}
	function delete_upload(){
		extract($_POST);
		$delete = $this->db->query("DELETE FROM fileup where id = $id");
		if($delete){
			return 1;
		}
	}
	
	function get_mpreport()
	{
		extract($_POST);
		$dept = $_POST["dept"];
		$st = $_POST["st"];
		if(isset($_POST['unit']))
		{
		$unit2 = $_POST["unit"];
		}
		if($dept != 0 && !empty($unit))
		{
			return 5;
			
		}
		else if($dept != 0 && empty($unit))
		{                                                                         
		if($st == 1) 
		{
		$qry = $this->db->query("select a.employee_id, concat(a.firstname,' ',a.lastname) as name,b.department,b.description,c.designation,concat(d.firstname,' ',d.lastname) as Evaluator_Name from employee_list a, department_list b,designation_list c,employee_list d where a.department_id = b.id and a.designation_id=c.id and a.evaluator_id=d.employee_id and a.department_id=$dept and a.doe='0000-00-00' and a.employee_id IN(SELECT employee_id from kpi_mster)");
		}
		else if($st == 2)
		{
		$qry = $this->db->query("select a.employee_id, concat(a.firstname,' ',a.lastname) as name,b.department,b.description,c.designation,concat(d.firstname,' ',d.lastname) as Evaluator_Name from employee_list a, department_list b,designation_list c,employee_list d where a.department_id = b.id and a.designation_id=c.id and a.evaluator_id=d.employee_id and a.department_id=$dept and a.doe='0000-00-00' and a.employee_id NOT IN(SELECT employee_id from kpi_mster)");	
		}
		}
		else if($dept == 0 && !empty($unit)) 
		{
			
			if($st == 1)
			{
			foreach($unit2 as $unit)
			{ 
			$qry1 = $this->db->query("select a.employee_id, concat(a.firstname,' ',a.lastname) as name,b.department,b.description,c.designation,concat(d.firstname,' ',d.lastname) as Evaluator_Name from employee_list a, department_list b,designation_list c,employee_list d where a.department_id = b.id and a.designation_id=c.id and a.evaluator_id=d.employee_id and a.middlename='$unit' and a.doe='0000-00-00' and a.employee_id IN(SELECT employee_id from kpi_mster) Order by department ASC");
			if($qry1->num_rows > 0)
			{
			$i=0;
			while($vals  =   $qry1->fetch_assoc()){
			$i+=1;
			?>
				<tr>
					<td><?=$i?></td>
					<td><?=$vals['employee_id']?></td>
					<td><?=$vals['name']?></td>
					<td><?=$vals['department']?></td>
					<td><?=$vals['description']?></td>
					<td><?=$vals['designation']?></td>
					<td><?=$vals['Evaluator_Name']?></td>
				</tr>
				<?php
			}
		}
		}
			}
			else if($st == 2)
			{
			foreach($unit2 as $unit)
			{
			$qry1 = $this->db->query("select a.employee_id, concat(a.firstname,' ',a.lastname) as name,b.department,b.description,c.designation,concat(d.firstname,' ',d.lastname) as Evaluator_Name from employee_list a, department_list b,designation_list c,employee_list d where a.department_id = b.id and a.designation_id=c.id and a.evaluator_id=d.employee_id and a.middlename='$unit' and a.doe='0000-00-00' and a.employee_id NOT IN(SELECT employee_id from kpi_mster) Order by department ASC");	
			if($qry1->num_rows > 0)
			{
				$i=0;
			while($vals  =   $qry1->fetch_assoc()){
				$i+=1;
				?>
					<tr>
						<td><?=$i?></td>
						<td><?=$vals['employee_id']?></td>
						<td><?=$vals['name']?></td>
						<td><?=$vals['department']?></td>
						<td><?=$vals['description']?></td>
						<td><?=$vals['designation']?></td>
						<td><?=$vals['Evaluator_Name']?></td>
					</tr>
					<?php
			}
		}
		}

		}
		EXIT();
		}
		else if(empty($unit2) && $dept == 0)
		{
		if($st == 1)
		{
		$qry = $this->db->query("select a.employee_id, concat(a.firstname,' ',a.lastname) as name,b.department,b.description,c.designation,concat(d.firstname,' ',d.lastname) as Evaluator_Name from employee_list a, department_list b,designation_list c,employee_list d where a.department_id = b.id and a.designation_id=c.id and a.evaluator_id=d.employee_id and a.doe='0000-00-00' and a.employee_id IN(SELECT employee_id from kpi_mster) Order by department ASC");
		}
		else if($st == 2)
		{
		$qry = $this->db->query("select a.employee_id, concat(a.firstname,' ',a.lastname) as name,b.department,b.description,c.designation,concat(d.firstname,' ',d.lastname) as Evaluator_Name from employee_list a, department_list b,designation_list c,employee_list d where a.department_id = b.id and a.designation_id=c.id and a.evaluator_id=d.employee_id and a.doe='0000-00-00' and a.employee_id NOT IN(SELECT employee_id from kpi_mster) Order by department ASC");	
		}
		}
		if($qry->num_rows > 0)
		{
			$i=0;
		while($vals  =   $qry->fetch_assoc()){
			$i+=1;
			?>
				<tr>
					<td><?=$i?></td>
					<td><?=$vals['employee_id']?></td>
					<td><?=$vals['name']?></td>
					<td><?=$vals['department']?></td>
					<td><?=$vals['description']?></td>
					<td><?=$vals['designation']?></td>
					<td><?=$vals['Evaluator_Name']?></td>
				</tr>
				<?php
		}
	}
	/*else
		{
			?>
			<tr>
			<td colspan="7" class="bg-light text-center"><strong>No Record(s) Found!</strong></td>
			</tr>
			<?php
		}	*/
	
		
	}
	function get_mpdetail()
	{
		extract($_POST);
		$dept = $_POST["dept"];
		$st = $_POST["st"];
		if(isset($_POST['unit']))
		{
		$unit2 = $_POST["unit"];
		}
		if($dept != 0 && !empty($unit))
		{
			return 5;
			
		}
		else if($dept != 0 && empty($unit))
		{		
		$qry = $this->db->query("select a.*,concat(b.firstname,' ',b.lastname) as name,c.department,c.description from kpi_mster a,employee_list b,department_list c where a.employee_id=b.employee_id and b.department_id = c.id and b.department_id=$dept and a.employee_id NOT IN(select employee_id from employee_list where doe!='0000-00-00') Order by department ASC");
		}
		else if($dept == 0 && !empty($unit)) 
		{
			foreach($unit2 as $unit)
		{
		$qry1 = $this->db->query("select a.*,concat(b.firstname,' ',b.lastname) as name,c.department,c.description from kpi_mster a,employee_list b,department_list c where a.employee_id=b.employee_id and b.department_id = c.id and b.middlename='$unit' and a.employee_id NOT IN(select employee_id from employee_list where doe!='0000-00-00') Order by department ASC");
		
		if($qry1->num_rows > 0)
		{
			$i=0;
		while($vals  =   $qry1->fetch_assoc()){
			$i+=1;
			?>
				<tr>
					<td><?=$i?></td>
					<td><?=$vals['employee_id']?></td>
					<td><?=$vals['name']?></td>
					<td><?=$vals['department']?></td>
					<td><?=$vals['description']?></td>
					<td><?=$vals['sno']?></td>
					<td><?=$vals['activities']?></td>
					<td><?=$vals['kpi']?></td>
					<td><?=$vals['uom']?></td>
					<td><?=$vals['ytd_target']?></td>
					<td><?=$vals['q1_target']?></td>
					<td><?=$vals['q2_target']?></td>
					<td><?=$vals['q3_target']?></td>
					<td><?=$vals['q4_target']?></td>
					<td><?=$vals['ytd_value']?></td>
				</tr>
				<?php
		}
	}
	} EXIT();
		}
		else if(empty($unit) && $dept == 0)
		{	
		$qry = $this->db->query("select a.*,concat(b.firstname,' ',b.lastname) as name,c.department,c.description from kpi_mster a,employee_list b,department_list c where a.employee_id=b.employee_id and b.department_id = c.id and a.employee_id NOT IN(select employee_id from employee_list where doe!='0000-00-00') Order by department ASC,employee_id ASC");		
		}
		if($qry->num_rows > 0)
		{
			$i=0;
		while($vals  =   $qry->fetch_assoc()){
			$i+=1;
			?>
				<tr>
					<td><?=$i?></td>
					<td><?=$vals['employee_id']?></td>
					<td><?=$vals['name']?></td>
					<td><?=$vals['department']?></td>
					<td><?=$vals['description']?></td>
					<td><?=$vals['sno']?></td>
					<td><?=$vals['activities']?></td>
					<td><?=$vals['kpi']?></td>
					<td><?=$vals['uom']?></td>
					<td><?=$vals['ytd_target']?></td>
					<td><?=$vals['q1_target']?></td>
					<td><?=$vals['q2_target']?></td>
					<td><?=$vals['q3_target']?></td>
					<td><?=$vals['q4_target']?></td>
					<td><?=$vals['ytd_value']?></td>
				</tr>
				<?php
		}
	}
	/*else
		{
			?>
			<tr>
			<td colspan="16" class="bg-light text-center"><strong>No Record(s) Found!</strong></td>
			</tr>
			<?php
		}*/	
	
	}
	function enable_prog()
	{
		print_r($_POST);
		
		$emp = $_POST["emp"];
		
	
		if($emp != 0)
		{
		$result	=	$this->db->query("SELECT a.id,a.task,a.year_from,a.year_to,a.mode,a.pperiod,a.employee_id,concat(c.firstname,' ',c.lastname) as name from task_list a,employee_list c where a.employee_id=c.employee_id and a.employee_id=$emp");
		}

		else
		{
			?>
			<tr>
			<td colspan="12" class="bg-light text-center"><strong>No Record(s) Found!</strong></td>
			</tr>
			<?php
			exit();
		}
		if($result->num_rows>0){
			$s	=	'';
				while($val  =   $result->fetch_assoc()){
				$id = $val['id'];
				$q = $this->db->query("SELECT * FROM task_list WHERE id=$id");
				$r = $q->fetch_assoc();
				$qry888 = $this->db->query("SELECT * FROM task_progress WHERE task_id=$id");
				$row888 = $qry888->fetch_array();
$qry88 = $this->db->query("SELECT * FROM ratings WHERE task_id=$id");
$row88 = $qry88->fetch_array();
//calculation for KPI
$qr = $this->db->query("SELECT SUM(ytd_actual) as ac_sum FROM apprisal_mop WHERE task_id=$id");
$rs = $qr->fetch_array();
$kpi_cal = round(($rs['ac_sum']/100)*75, 2);

$qrs1 = $this->db->query("SELECT SUM(ytd_actual1) as ac_sum FROM apprisal_mop WHERE task_id=$id");
$rss1 = $qrs1->fetch_array();
$kpi_cal1 = round(($rss1['ac_sum']/100)*75, 2);
//Calculation for self traits
$qr1 = $this->db->query("SELECT SUM(self) as self_sum FROM apprisal_rate WHERE task_id=$id");
$rs1 = $qr1->fetch_array();
$self_cal = round(($rs1['self_sum']/50)*25, 2);
//Calculation for Approver traits
$qr2 = $this->db->query("SELECT SUM(appraiser) as app_sum FROM apprisal_rate WHERE task_id=$id");
$rs2 = $qr2->fetch_array();
$app_cal = round(($rs2['app_sum']/50)*25, 2);
//total for self percentage
$total_self = $kpi_cal + $self_cal;
//total for Approver percentage
$total_app = $kpi_cal1 + $app_cal;
//echo round($kpi_cal, 2);
?>
			
			<tr>
				<td><?php echo $val['id']; ?></td>
				<td><b><?=$val['name']." - ".$val['employee_id'];?></b></td>
				<td><b style='color:green'><?=$val['task'].' '.$val['year_from'].' - '.$val['year_to']?>&nbsp;<?=$val['mode'].' - '.$val['pperiod']?></b><br>
				<?php
				if($r['status'] == '2')
				{
				?><span style="border:1px solid green;padding:2px;background:green;color:white;">Self Completed</span> &nbsp;<?php
				}
				if(($r['status1'] == '1'))
				{
					?><span style="border:1px solid green;padding:2px;background:blue;color:white;">Evaluated</span><?php
				}
				?>
			</td>
                <td><input type="checkbox" class="form-control" id="self<?=$id?>" name="sel<?=$id?>" style="width:20px;" value="1" <?php if($r['status'] != '2') echo "disabled";  ?> ><span style="font-size:14px;color:blue">Self</span></td>
                <td><input type="checkbox" class="form-control" id="eval<?=$id?>" name="eval<?=$id?>" style="width:20px;" value="2" <?php if($r['status1'] != '1') echo "disabled";  ?>><span style="font-size:14px;color:blue">Evaluator</span></td>
				<td><button type="button" class="btn btn-success" onclick=ds(<?php echo $id?>);>Reverse</button></td>

			</tr>
			<?php
			}
		}else{ ?>
		<tr>
			<td colspan="12" class="bg-light text-center"><strong>No Record(s) Found!</strong></td>
		</tr>
		<?php } 
	}
	function en_prog()
	{
		$t = $_POST['ids'];
		echo "UPDATE task_progress set is_complete=0 where task_id = $t";
		$this->db->query("UPDATE task_progress set is_complete=0 where task_id = $t");
		$this->db->query("UPDATE task_list set status=1,status1=0 where task_id = $t");
		$this->db->query("DELETE FROM ratings where task_id = $t");
	}
	function ds_prog()
	{
		$t = $_POST['ids'];
		$s = $_POST['s'];
		$i = $_POST['i'];
		if($s != 0)
		{
		$this->db->query("UPDATE task_progress set is_complete=0 where task_id = $t");
		$this->db->query("UPDATE task_list set status=1 where id = $t");
		}
		if($i != 0)
		{
		//$this->db->query("UPDATE task_progress set is_complete=1 where task_id = $t");
		$this->db->query("UPDATE task_list set status1=0,ev_by=NULL,ev_date=NULL where id = $t");
		$this->db->query("UPDATE ratings set hod_per=0,hstatus_by=NULL,hstatus_date=NULL where task_id = $t");

		}
		// $this->db->query("UPDATE task_progress set is_complete=1 where task_id = $t");
		// $this->db->query("UPDATE task_list set status=2 where task_id = $t");
	}
	function update_cal()
	{
		$id = $_POST['id'];
		$q = $this->db->query("SELECT * FROM kpi_mster WHERE id=$id");
		$r = $q->fetch_assoc();
		if($r['cal'] == 1)
		{
			$this->db->query("UPDATE kpi_mster set cal=0 where id = $id");
		}
		else if($r['cal'] == 0)
		{			
			$this->db->query("UPDATE kpi_mster set cal=1 where id = $id");
		}
		//$this->db->query("UPDATE kpi_master set cal=1 where task_id = $t");
		// $this->db->query("UPDATE task_list set status=2 where task_id = $t");
	}
	function mp_cal()
	{
		$id = $_POST['kpi']; $cal = $_POST['cal'];
		//echo "UPDATE kpi_mster set cal=$cal where id = $id";
		$this->db->query("UPDATE kpi_mster set cal=$cal where id = $id");
		
		//$this->db->query("UPDATE kpi_master set cal=1 where task_id = $t");
		// $this->db->query("UPDATE task_list set status=2 where task_id = $t");
	}
	function update_mop()
	{
		$id = $_POST['id'];
		$emp = $_POST['emp'];
		$t = $this->db->query("SELECT * FROM task_list WHERE id=$id");
		$tr = $t->fetch_assoc(); $p = $tr['pperiod'];
		$q = $this->db->query("SELECT * FROM kpi_mster WHERE employee_id=$emp and status=0");
		while($r = $q->fetch_assoc())
		{
			$kpi_id = $r['id'];
			$sno = $r['sno'];
			$act = $this->db->real_escape_string($r['activities']);
			$kpi = $this->db->real_escape_string($r['kpi']);
			$uom = $this->db->real_escape_string($r['uom']);
			$target = $r[$p.'_target'];
			$ytd_target = $r['ytd_target'];
			$cal = $r['cal'];
		$qq = $this->db->query("SELECT * FROM apprisal_mop WHERE task_id=$id and kpi_id=$kpi_id");
		if($qq->num_rows == 0)
		{
			$save = $this->db->query("INSERT INTO apprisal_mop(sno,activities,kpi,uom,target,ytd_target,cal) values ($sno,'$act','$kpi','$uom',$target,$ytd_target,$cal)");

		}
		
		else
		{
			$save = $this->db->query("UPDATE apprisal_mop set sno=$sno,activities='$act',kpi='$kpi',uom='$uom',target=$target,ytd_target=$ytd_target,cal=$cal where task_id = $id and kpi_id=$kpi_id");
		}
		}
		//$qqq = $this->db->query("SELECT * FROM apprisal_mop WHERE task_id=$id and kpi_id not in (select kpi_id from kpi_mster where status=0)");

		
		$this->db->query("DELETE FROM apprisal_mop where task_id = $id and kpi_id not in (select id from kpi_mster where status=0)");

		if($save)
		{
			echo "1";
		}

	}

	function save_ticket(){
		extract($_POST);
		//print_r($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$data .= ", req_by = {$_SESSION['login_employee_id']} ";
		$save = $this->db->query("INSERT INTO tickets set $data");		
		if($save){
		if(!isset($is_complete))
			return 1;
		}
	}
	function save_team(){
		extract($_POST);
		//print_r($_POST);
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		//echo "INSERT INTO team_list set $data";
		$save = $this->db->query("INSERT INTO team_list set $data");		
		if($save){
		if(!isset($is_complete))
			return 1;
		}
	}
	function get_subcat(){
		$cat = $_POST["cat"];
		?>
		          <div class="form-group">
						<label for="">Sub-Category</label>
						<select name="sub_category" id="sub_category" class="form-control form-control-sm select2" required="">
						
							<?php 
							
								//echo "SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where department_id=$dept and doe='0000-00-00' and (evaluator_id=$ev_id or evaluator2_id=$ev_id) order by concat(firstname,' ',lastname) asc";
								//echo "SELECT *,concat(firstname,' ',lastname) as name FROM employee_list where department_id=$dept and doe='0000-00-00' and employee_id!={$_SESSION['login_employee_id']} order by concat(firstname,' ',lastname) asc";
							echo "SELECT * from sub_category where category='$cat' order by id asc";
								$sub = $this->db->query("SELECT * from sub_category where category='$cat' order by id asc");
	
							
							while($row=$sub->fetch_assoc()):
							?>
							<option value="<?php echo $row['id'] ?>" selected><?php echo $row['sub_category']?></option>
							<?php endwhile; ?>
							<option value="0" selected>Please Select Here</option>
						</select>
					</div>
		<?php
	}
	function save_scategory()
	{
		extract($_POST);
		if(($_POST['category'] == ""))
		{
			return 3;
		}
		$data = "";
		foreach($_POST as $k => $v){
			if(!in_array($k, array('id','user_ids')) && !is_numeric($k)){
				if(empty($data)){
					$data .= " $k='$v' ";
				}else{
					$data .= ", $k='$v' ";
				}
			}
		}
		$chk = $this->db->query("SELECT * FROM sub_category where sub_category = '$category'")->num_rows;
		if($chk > 0){
			return 2;
		}
		if(isset($user_ids)){
			$data .= ", user_ids='".implode(',',$user_ids)."' ";
		}
		if(empty($id)){
			$save = $this->db->query("INSERT INTO sub_category set $data");
		}else{
			$save = $this->db->query("UPDATE sub_category set $data where id = $id");
		}
		if($save){
			return 1;
		}
	}
	function self_assign()
	{
		extract($_POST);
		//$d = date('Y-m-d h:i:s');
		//echo "UPDATE  set `status`=1,`assigned_date`=date('Y-m-d h:i:s') where id = $id";
		$ass = $this->db->query("UPDATE tickets set `status`=1,`assigned_to`={$_SESSION['login_employee_id']},`assigned_date`=CURRENT_TIMESTAMP where id = $id");
		if($ass)
			return 1;
	}

	function update_status()
	{
		//print_r($_POST);
		extract($_POST);
		//$d = date('Y-m-d h:i:s');
		//echo "UPDATE  set `status`=1,`assigned_date`=date('Y-m-d h:i:s') where id = $id";
		//echo "UPDATE tickets set `attend_date`='$attend_date',`reached_time`='$reached_time',`resolve_date`='$resolve_date',`resolve_time`='$resolve_time' where id = $id";
		$ass = $this->db->query("UPDATE tickets set `attend_date`='$attend_date',`reached_time`='$reached_time',`resolve_date`='$resolve_date',`resolve_time`='$resolve_time',status=2 where id = $id");
		if($ass)
			return 1;
	}
}