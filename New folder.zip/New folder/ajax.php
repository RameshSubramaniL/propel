<?php
ob_start();
date_default_timezone_set("Asia/Manila");

$action = $_GET['action'];
include 'admin_class.php';
$crud = new Action();
if($action == 'login'){
	$login = $crud->login();
	if($login)
		echo $login;
}
if($action == 'login2'){
	$login = $crud->login2();
	if($login)
		echo $login;
}
if($action == 'logout'){
	$logout = $crud->logout();
	if($logout)
		echo $logout;
}
if($action == 'logout2'){
	$logout = $crud->logout2();
	if($logout)
		echo $logout;
}

if($action == 'signup'){
	$save = $crud->signup();
	if($save)
		echo $save;
}
if($action == 'save_user'){
	$save = $crud->save_user();
	if($save)
		echo $save;
}
if($action == 'update_user'){
	$save = $crud->update_user();
	if($save)
		echo $save;
}
if($action == 'delete_user'){
	$save = $crud->delete_user();
	if($save)
		echo $save;
}
if($action == 'save_department'){
	$save = $crud->save_department();
	if($save)
		echo $save;
}
if($action == 'delete_department'){
	$save = $crud->delete_department();
	if($save)
		echo $save;
}
if($action == 'save_designation'){
	$save = $crud->save_designation();
	if($save)
		echo $save;
}
if($action == 'delete_designation'){
	$save = $crud->delete_designation();
	if($save)
		echo $save;
}
if($action == 'save_employee'){
	$save = $crud->save_employee();
	if($save)
		echo $save;
}
if($action == 'delete_employee'){
	$save = $crud->delete_employee();
	if($save)
		echo $save;
}
if($action == 'save_evaluator'){
	$save = $crud->save_evaluator();
	if($save)
		echo $save;
}
if($action == 'delete_evaluator'){
	$save = $crud->delete_evaluator();
	if($save)
		echo $save;
}
if($action == 'save_task'){
	$save = $crud->save_task();
	if($save)
		echo $save;
}
if($action == 'delete_task'){
	$save = $crud->delete_task();
	if($save)
		echo $save;
}
if($action == 'save_progress'){
	$save = $crud->save_progress();
	if($save)
		echo $save;
}
if($action == 'delete_progress'){
	$save = $crud->delete_progress();
	if($save)
		echo $save;
}
if($action == 'save_evaluation'){
	$save = $crud->save_evaluation();
	if($save)
		echo $save;
}
if($action == 'delete_evaluation'){
	$save = $crud->delete_evaluation();
	if($save)
		echo $save;
}
if($action == 'get_emp_tasks'){
	$get = $crud->get_emp_tasks();
	if($get)
		echo $get;
}
if($action == 'get_progress'){
	$get = $crud->get_progress();
	if($get)
		echo $get;
}
if($action == 'get_report'){
	$get = $crud->get_report();
	if($get)
		echo $get;
}
if($action == 'get_dept_id'){
	$get = $crud->get_dept_id();
	if($get)
		echo $get;
}
if($action == 'add_more'){
	$get = $crud->add_more();
	if($get)
		echo $get;
}
if($action == 'get_dept_ids'){
	$get = $crud->get_dept_ids();
	if($get)
		echo $get;
}
if($action == 'get_mop'){
	$get = $crud->get_mop();
	if($get)
		echo $get;
}
if($action == 'save_mop'){
	$get = $crud->save_mop();
	if($get)
		echo $get;
}
if($action == 'live_edit'){
	$get = $crud->live_edit();
	if($get)
		echo $get;
}
if($action == 'delete_kpi'){
	$save = $crud->delete_kpi();
	if($save)
		echo $save;
}
if($action == 'get_reports'){
	$save = $crud->get_reports();
	if($save)
		echo $save;
}
if($action == 'get_uploads'){
	$get = $crud->get_uploads();
	if($get)
		echo $get;
}
if($action == 'delete_upload'){
	$save = $crud->delete_upload();
	if($save)
		echo $save;
}
if($action == 'get_mpreport'){
	$save = $crud->get_mpreport();
	if($save)
		echo $save;
}
if($action == 'get_mpdetail'){
	$save = $crud->get_mpdetail();
	if($save)
		echo $save;
}
if($action == 'enable_prog'){
	$save = $crud->enable_prog();
	if($save)
		echo $save;
}
if($action == 'en_prog'){
	$save = $crud->en_prog();
	if($save)
		echo $save;
}
if($action == 'ds_prog'){
	$save = $crud->ds_prog();
	if($save)
		echo $save;
}
if($action == 'update_cal'){
	$save = $crud->update_cal();
	if($save)
		echo $save;
}
if($action == 'mp_cal'){
	$save = $crud->mp_cal();
	if($save)
		echo $save;
}
if($action == 'update_mop'){
	$save = $crud->update_mop();
	if($save)
		echo $save;
}
if($action == 'save_ticket'){
	$save = $crud->save_ticket();
	if($save)
		echo $save;
}
if($action == 'save_team'){
	$save = $crud->save_team();
	if($save)
		echo $save;
}
if($action == 'save_scategory'){
	$save = $crud->save_scategory();
	if($save)
		echo $save;
}
if($action == 'get_subcat'){
	$get = $crud->get_subcat();
	if($get)
		echo $get;
}
if($action == 'self_assign'){
	$save = $crud->self_assign();
	if($save)
		echo $save;
}
if($action == 'update_status'){
	$save = $crud->update_status();
	if($save)
		echo $save;
}
ob_end_flush();
?>
